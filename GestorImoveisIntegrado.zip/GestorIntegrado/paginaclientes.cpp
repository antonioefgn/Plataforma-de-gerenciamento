#include "paginaclientes.h"
#include "ui_paginaclientes.h"

#include <QHeaderView>
#include <QMessageBox>
#include <QRegularExpression>
#include <QRegularExpressionValidator>

#include "sistema.h"

PaginaClientes::PaginaClientes(QWidget *parent) : QWidget(parent), ui(new Ui::PaginaClientes)
{
    ui->setupUi(this);
    ui->tabelaClientes->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->splitter->setStretchFactor(0, 3);
    ui->splitter->setStretchFactor(1, 2);
    ui->editTelefone->setValidator(
        new QRegularExpressionValidator(QRegularExpression("[0-9 ()+\\-]*"), this));

    connect(ui->btnNovoClienteLista, &QPushButton::clicked, this, [this] { novo(); });
    connect(ui->btnSalvarCliente, &QPushButton::clicked, this, [this] { salvar(); });
    connect(ui->btnExcluirCliente, &QPushButton::clicked, this, [this] { excluir(); });
    connect(ui->editBusca, &QLineEdit::textChanged, this, [this] { atualizarLista(); });
    connect(ui->tabelaClientes, &QTableWidget::itemSelectionChanged, this, [this] { aoSelecionar(); });
    connect(&Sistema::instancia(), &Sistema::dadosAlterados, this, [this] { atualizarLista(); });

    atualizarLista();
}

PaginaClientes::~PaginaClientes()
{
    delete ui;
}

void PaginaClientes::resizeEvent(QResizeEvent *e)
{
    QWidget::resizeEvent(e);
    ui->splitter->setOrientation(width() < 860 ? Qt::Vertical : Qt::Horizontal);
}

void PaginaClientes::atualizarLista()
{
    const QString filtro = ui->editBusca->text().trimmed();
    QList<HospedeInfo> lista;
    for (const HospedeInfo &h : Sistema::instancia().hospedes()) {
        if (filtro.isEmpty() || h.nome.contains(filtro, Qt::CaseInsensitive)
            || h.documento.contains(filtro, Qt::CaseInsensitive)
            || h.telefone.contains(filtro, Qt::CaseInsensitive)
            || h.email.contains(filtro, Qt::CaseInsensitive))
            lista.append(h);
    }

    QTableWidget *t = ui->tabelaClientes;
    t->blockSignals(true);
    t->setRowCount(lista.size());
    int linhaAtual = -1;
    for (int r = 0; r < lista.size(); ++r) {
        const HospedeInfo &h = lista[r];
        auto *nome = new QTableWidgetItem(h.nome);
        nome->setData(Qt::UserRole, h.documento);
        t->setItem(r, 0, nome);
        t->setItem(r, 1, new QTableWidgetItem(h.documento));
        t->setItem(r, 2, new QTableWidgetItem(h.telefone));
        t->setItem(r, 3, new QTableWidgetItem(h.email));
        if (!m_docAtual.isEmpty() && h.documento == m_docAtual)
            linhaAtual = r;
    }
    if (linhaAtual >= 0)
        t->selectRow(linhaAtual);
    else
        t->clearSelection();
    t->blockSignals(false);
}

void PaginaClientes::aoSelecionar()
{
    const auto itens = ui->tabelaClientes->selectedItems();
    if (itens.isEmpty())
        return;
    carregarFormulario(ui->tabelaClientes->item(itens.first()->row(), 0)->data(Qt::UserRole).toString());
}

void PaginaClientes::carregarFormulario(const QString &documento)
{
    const HospedeInfo h = Sistema::instancia().hospede(documento);
    if (h.documento.isEmpty())
        return;
    m_docAtual = h.documento;
    ui->editNomeCliente->setText(h.nome);
    ui->editDocumento->setText(h.documento);
    ui->editTelefone->setText(h.telefone);
    ui->editEmail->setText(h.email);
}

void PaginaClientes::limparFormulario()
{
    m_docAtual.clear();
    ui->editNomeCliente->clear();
    ui->editDocumento->clear();
    ui->editTelefone->clear();
    ui->editEmail->clear();
}

void PaginaClientes::novo()
{
    ui->tabelaClientes->clearSelection();
    limparFormulario();
    ui->editNomeCliente->setFocus();
}

void PaginaClientes::salvar()
{
    const QString email = ui->editEmail->text().trimmed();
    if (!email.isEmpty()
        && !QRegularExpression("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$").match(email).hasMatch()) {
        QMessageBox::warning(this, tr("Cliente"), tr("E-mail inválido."));
        ui->editEmail->setFocus();
        return;
    }
    HospedeInfo h;
    h.nome = ui->editNomeCliente->text().trimmed();
    h.documento = ui->editDocumento->text().trimmed();
    h.telefone = ui->editTelefone->text().trimmed();
    h.email = email;

    QString erro;
    if (!Sistema::instancia().salvarHospede(m_docAtual, h, &erro)) {
        QMessageBox::warning(this, tr("Cliente"), erro);
        return;
    }
    m_docAtual = h.documento;
    atualizarLista();
    QMessageBox::information(this, tr("Cliente"), tr("Cliente salvo com sucesso!"));
}

void PaginaClientes::excluir()
{
    if (m_docAtual.isEmpty()) {
        QMessageBox::information(this, tr("Cliente"), tr("Selecione um cliente na lista."));
        return;
    }
    if (Sistema::instancia().hospedeTemReservas(m_docAtual)) {
        QMessageBox::warning(this, tr("Cliente"),
                             tr("Este cliente possui reservas e não pode ser excluído.\n"
                                "Exclua as reservas dele primeiro."));
        return;
    }
    if (QMessageBox::question(this, tr("Excluir cliente"), tr("Excluir este cliente?"))
        != QMessageBox::Yes)
        return;
    const QString doc = m_docAtual;
    limparFormulario();
    Sistema::instancia().excluirHospede(doc);
}
