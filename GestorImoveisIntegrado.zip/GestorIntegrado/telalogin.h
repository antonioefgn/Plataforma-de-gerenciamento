#pragma once

#include <QDialog>

namespace Ui { class TelaLogin; }

// Única parte com funcionamento real: valida usuário e senha fixos.
// O visual está em telalogin.ui (abra no Qt Designer).
class TelaLogin : public QDialog {
public:
    explicit TelaLogin(QWidget *parent = nullptr);
    ~TelaLogin() override;

private:
    void tentarLogin();

    Ui::TelaLogin *ui;
};
