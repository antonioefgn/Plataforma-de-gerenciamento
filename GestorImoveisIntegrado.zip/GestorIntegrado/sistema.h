#pragma once

#include <QDate>
#include <QList>
#include <QObject>
#include <QString>
#include <QStringList>
#include <memory>

// ---------------------------------------------------------------------------
// "Ponte" entre a interface Qt e as classes da equipe (pasta classes/).
//
// As telas NUNCA usam Imovel, Reserva, Hospede etc. diretamente: elas conversam
// só com a classe Sistema, que usa as classes da equipe por baixo dos panos.
// Assim, se uma classe da equipe mudar, só o sistema.cpp precisa ser ajustado.
// ---------------------------------------------------------------------------

struct ImovelInfo {
    int id = 0; // 0 = imóvel novo (ainda não salvo)
    QString titulo;
    double diaria = 0.0;
    QString endereco;
    QString descricao;
    QString foto;
    int capacidade = 1;
};

struct HospedeInfo {
    QString nome;
    QString documento; // identifica o hóspede (não pode repetir)
    QString telefone;
    QString email;
};

struct ReservaInfo {
    int imovelId = 0;
    int indice = 0; // posição da reserva dentro do imóvel
    HospedeInfo hospede;
    QDate checkIn;
    QDate checkOut;
    QString plataforma;
    double bruto = 0.0;
    double liquido = 0.0;

    int noites() const { return static_cast<int>(checkIn.daysTo(checkOut)); }
};

// Linha de relatório financeiro (por imóvel, por plataforma ou total)
struct LinhaRelatorio {
    QString nome;
    int reservas = 0;
    double bruto = 0.0;
    double liquido = 0.0;
};

// Resultado da importação de reservas de um arquivo
struct ResultadoImportacaoInfo {
    QStringList aceitas;
    QStringList conflitos; // overbooking
    QStringList invalidas;
    QString erro;          // preenchido se o arquivo nem pôde ser lido
};

QString moeda(double valor);   // 1234.5 -> "R$ 1.234,50"
QString dataBR(const QDate &d); // dd/MM/yyyy

struct DadosSistema; // definido em sistema.cpp (usa as classes da equipe)

class Sistema : public QObject {
    Q_OBJECT
public:
    static Sistema &instancia();
    ~Sistema() override;

    QString pastaDeDados() const; // onde ficam dados.json e a pasta fotos/

    // ----- Imóveis -----
    QList<ImovelInfo> imoveis() const;
    ImovelInfo imovel(int id) const; // id == 0 se não existir
    int salvarImovel(const ImovelInfo &info); // id == 0 cria; devolve o id
    void excluirImovel(int id);               // apaga também as reservas dele

    // ----- Hóspedes (clientes) -----
    QList<HospedeInfo> hospedes() const;
    HospedeInfo hospede(const QString &documento) const; // documento vazio se não existir
    bool salvarHospede(const QString &documentoAnterior, const HospedeInfo &h, QString *erro);
    bool hospedeTemReservas(const QString &documento) const;
    void excluirHospede(const QString &documento);

    // ----- Reservas -----
    QStringList plataformas() const;
    QList<ReservaInfo> reservasDoImovel(int imovelId) const;
    QList<ReservaInfo> todasReservas() const;
    double calcularBruto(int imovelId, const QDate &in, const QDate &out) const;
    double calcularLiquido(const QString &plataforma, double bruto) const;
    // "avisosSincronizacao" recebe as mensagens simuladas de bloqueio nas outras plataformas
    bool registrarReserva(int imovelId, const HospedeInfo &h, const QDate &in,
                          const QDate &out, const QString &plataforma, QString *erro,
                          QStringList *avisosSincronizacao = nullptr);
    void excluirReserva(int imovelId, int indice);
    QStringList exportarReservas() const; // usa formatarExportacao() de cada plataforma

    // Importa um arquivo de reservas (ex.: novas_reservas_airbnb.txt) e diz quais foram aceitas
    ResultadoImportacaoInfo importarReservas(const QString &caminho);
    // Planilha .csv (abre no Excel) com todas as reservas e os totais
    bool exportarPlanilha(const QString &caminho, QString *erro) const;

    // ----- Relatório financeiro -----
    QList<LinhaRelatorio> relatorioPorImovel() const;
    QList<LinhaRelatorio> relatorioPorPlataforma() const;
    LinhaRelatorio relatorioTotal() const;

signals:
    void dadosAlterados();

private:
    Sistema();
    void salvarArquivo() const;
    void carregarArquivo();
    void garantirHospedesDasReservas(); // todo hóspede de uma reserva aparece na lista de clientes

    std::unique_ptr<DadosSistema> d;
};
