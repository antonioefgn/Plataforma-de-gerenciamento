#include "paginareservas.h"
#include "ui_paginareservas.h"

#include <QFile>
#include <QFileDialog>
#include <QHeaderView>
#include <QMessageBox>
#include <QSignalBlocker>
#include <QTextStream>

#include "sistema.h"

PaginaReservas::PaginaReservas(QWidget *parent) : QWidget(parent), ui(new Ui::PaginaReservas)
{
    ui->setupUi(this);

    // Colunas ajustadas ao conteúdo; só a do nome do hóspede estica
    ui->tabelaReservas->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->tabelaReservas->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);
    ui->splitter->setStretchFactor(0, 2);
    ui->splitter->setStretchFactor(1, 3);
    ui->dateCheckIn->setDate(QDate::currentDate());
    ui->dateCheckOut->setDate(QDate::currentDate().addDays(1));
    ui->comboPlataforma->addItems(Sistema::instancia().plataformas());

    connect(ui->comboImovel, &QComboBox::currentIndexChanged, this, [this] { aoMudarImovel(); });
    connect(ui->radioVer, &QRadioButton::toggled, this, [this] { aoMudarModo(); });
    connect(ui->calendario, &QCalendarWidget::clicked, this,
            [this](const QDate &d) { aoClicarData(d); });
    connect(ui->dateCheckIn, &QDateEdit::dateChanged, this, [this] { aoMudarDatas(); });
    connect(ui->dateCheckOut, &QDateEdit::dateChanged, this, [this] { aoMudarDatas(); });
    connect(ui->comboPlataforma, &QComboBox::currentIndexChanged, this, [this] { atualizarTotais(); });
    connect(ui->btnRegistrar, &QPushButton::clicked, this, [this] { registrar(); });
    connect(ui->btnLimpar, &QPushButton::clicked, this, [this] { limparFormulario(); });
    connect(ui->btnNovoCliente, &QPushButton::clicked, this, &PaginaReservas::irParaClientes);
    connect(ui->btnExcluirReserva, &QPushButton::clicked, this, [this] { excluirReserva(); });
    connect(ui->btnExportar, &QPushButton::clicked, this, [this] { exportar(); });
    connect(ui->btnImportar, &QPushButton::clicked, this, [this] { importar(); });
    connect(&Sistema::instancia(), &Sistema::dadosAlterados, this, [this] { atualizarCombos(); });

    atualizarCombos();
}

PaginaReservas::~PaginaReservas()
{
    delete ui;
}

void PaginaReservas::resizeEvent(QResizeEvent *e)
{
    QWidget::resizeEvent(e);
    ui->splitter->setOrientation(width() < 900 ? Qt::Vertical : Qt::Horizontal);
}

int PaginaReservas::imovelAtual() const
{
    return ui->comboImovel->currentData().toInt();
}

// Recarrega os combos (imóveis e hóspedes) quando qualquer dado muda
void PaginaReservas::atualizarCombos()
{
    auto &sistema = Sistema::instancia();
    m_atualizando = true;

    const int imovelAnterior = imovelAtual();
    ui->comboImovel->clear();
    for (const ImovelInfo &i : sistema.imoveis())
        ui->comboImovel->addItem(i.titulo, i.id);
    const int idx = ui->comboImovel->findData(imovelAnterior);
    if (idx >= 0)
        ui->comboImovel->setCurrentIndex(idx);

    const QString docAnterior = ui->comboHospede->currentData().toString();
    ui->comboHospede->clear();
    for (const HospedeInfo &h : sistema.hospedes())
        ui->comboHospede->addItem(h.nome + "  (" + h.documento + ")", h.documento);
    const int ih = ui->comboHospede->findData(docAnterior);
    if (ih >= 0)
        ui->comboHospede->setCurrentIndex(ih);

    m_atualizando = false;
    aoMudarImovel();
}

void PaginaReservas::aoMudarImovel()
{
    if (m_atualizando)
        return;
    preencherTabela();
    atualizarCalendario();
    atualizarTotais();
}

void PaginaReservas::aoMudarModo()
{
    const bool ver = ui->radioVer->isChecked();
    ui->painel->setCurrentIndex(ver ? 0 : 1);
    m_aguardandoSaida = false;
    if (ver)
        ui->calendario->setSelecao(QDate(), QDate());
    else
        aoMudarDatas();
}

void PaginaReservas::preencherTabela()
{
    QList<ReservaInfo> lista = Sistema::instancia().reservasDoImovel(imovelAtual());
    std::sort(lista.begin(), lista.end(),
              [](const ReservaInfo &a, const ReservaInfo &b) { return a.checkIn < b.checkIn; });

    QTableWidget *t = ui->tabelaReservas;
    t->setRowCount(lista.size());
    for (int r = 0; r < lista.size(); ++r) {
        const ReservaInfo &rv = lista[r];
        auto *nome = new QTableWidgetItem(rv.hospede.nome);
        nome->setData(Qt::UserRole, rv.indice); // posição da reserva dentro do imóvel
        t->setItem(r, 0, nome);
        t->setItem(r, 1, new QTableWidgetItem(dataBR(rv.checkIn)));
        t->setItem(r, 2, new QTableWidgetItem(dataBR(rv.checkOut)));
        t->setItem(r, 3, new QTableWidgetItem(QString::number(rv.noites())));
        t->setItem(r, 4, new QTableWidgetItem(rv.plataforma));
        t->setItem(r, 5, new QTableWidgetItem(moeda(rv.bruto)));
        t->setItem(r, 6, new QTableWidgetItem(moeda(rv.liquido)));
    }
}

void PaginaReservas::atualizarCalendario()
{
    ui->calendario->setReservas(Sistema::instancia().reservasDoImovel(imovelAtual()));
}

void PaginaReservas::mostrarResumoDia(const QDate &data)
{
    QStringList linhas;
    for (const ReservaInfo &r : Sistema::instancia().reservasDoImovel(imovelAtual())) {
        if (data < r.checkIn || data > r.checkOut)
            continue;
        const QString papel = data == r.checkIn ? tr("check-in")
                              : data == r.checkOut ? tr("check-out") : tr("hospedado");
        linhas << QString("• %1 — %2 (%3 a %4, %5)")
                      .arg(r.hospede.nome, papel, dataBR(r.checkIn), dataBR(r.checkOut), r.plataforma);
    }
    ui->resumoDia->setText(linhas.isEmpty() ? tr("%1: dia livre.").arg(dataBR(data))
                                            : tr("%1:\n%2").arg(dataBR(data), linhas.join("\n")));
}

// Clique no calendário: no modo "ver" mostra detalhes; no modo "novo" escolhe as datas
void PaginaReservas::aoClicarData(const QDate &data)
{
    if (ui->radioVer->isChecked()) {
        mostrarResumoDia(data);
        return;
    }
    // 1º clique = check-in; 2º clique (depois do check-in) = check-out
    if (!m_aguardandoSaida || data <= ui->dateCheckIn->date()) {
        ui->dateCheckIn->setDate(data);
        ui->dateCheckOut->setDate(data.addDays(1));
        m_aguardandoSaida = true;
    } else {
        ui->dateCheckOut->setDate(data);
        m_aguardandoSaida = false;
    }
}

void PaginaReservas::aoMudarDatas()
{
    if (ui->dateCheckOut->date() <= ui->dateCheckIn->date()) {
        QSignalBlocker bloqueio(ui->dateCheckOut);
        ui->dateCheckOut->setDate(ui->dateCheckIn->date().addDays(1));
    }
    if (ui->radioNovo->isChecked())
        ui->calendario->setSelecao(ui->dateCheckIn->date(), ui->dateCheckOut->date());
    atualizarTotais();
}

void PaginaReservas::atualizarTotais()
{
    auto &sistema = Sistema::instancia();
    const ImovelInfo imovel = sistema.imovel(imovelAtual());
    if (imovel.id == 0) {
        ui->valorBruto->setText("—");
        ui->valorLiquido->setText("—");
        return;
    }
    const QDate in = ui->dateCheckIn->date(), out = ui->dateCheckOut->date();
    const double bruto = sistema.calcularBruto(imovel.id, in, out);
    const double liquido = sistema.calcularLiquido(ui->comboPlataforma->currentText(), bruto);
    ui->valorBruto->setText(tr("%1 noite(s) × %2 = %3")
                                .arg(in.daysTo(out))
                                .arg(moeda(imovel.diaria), moeda(bruto)));
    ui->valorLiquido->setText(moeda(liquido));
}

void PaginaReservas::limparFormulario()
{
    ui->dateCheckIn->setDate(QDate::currentDate());
    ui->dateCheckOut->setDate(QDate::currentDate().addDays(1));
    ui->comboPlataforma->setCurrentIndex(0);
}

void PaginaReservas::registrar()
{
    auto &sistema = Sistema::instancia();
    if (imovelAtual() == 0) {
        QMessageBox::warning(this, tr("Aluguel"), tr("Cadastre um imóvel antes de registrar um aluguel."));
        return;
    }
    const QString documento = ui->comboHospede->currentData().toString();
    if (documento.isEmpty()) {
        QMessageBox::warning(this, tr("Aluguel"), tr("Cadastre ou selecione um cliente primeiro."));
        return;
    }
    QString erro;
    QStringList avisos;
    const bool ok = sistema.registrarReserva(imovelAtual(), sistema.hospede(documento),
                                             ui->dateCheckIn->date(), ui->dateCheckOut->date(),
                                             ui->comboPlataforma->currentText(), &erro, &avisos);
    if (!ok) {
        QMessageBox::warning(this, tr("Aluguel"), erro);
        return;
    }
    // Passo 8 do plano: aviso (simulado) de bloqueio das datas nas outras plataformas
    QString mensagem = tr("Aluguel registrado com sucesso!");
    if (!avisos.isEmpty())
        mensagem += tr("\n\nSincronização (simulada):\n") + avisos.join("\n");
    QMessageBox::information(this, tr("Aluguel"), mensagem);
    limparFormulario();
    ui->radioVer->setChecked(true);
}

void PaginaReservas::excluirReserva()
{
    const auto itens = ui->tabelaReservas->selectedItems();
    if (itens.isEmpty()) {
        QMessageBox::information(this, tr("Reserva"), tr("Selecione uma reserva na tabela."));
        return;
    }
    if (QMessageBox::question(this, tr("Excluir reserva"), tr("Excluir esta reserva definitivamente?"))
        != QMessageBox::Yes)
        return;
    const int indice = ui->tabelaReservas->item(itens.first()->row(), 0)->data(Qt::UserRole).toInt();
    Sistema::instancia().excluirReserva(imovelAtual(), indice);
}

void PaginaReservas::exportar()
{
    QString filtroEscolhido;
    const QString caminho = QFileDialog::getSaveFileName(
        this, tr("Exportar reservas"), "reservas.csv",
        tr("Planilha - abre no Excel (*.csv);;Texto (*.txt)"), &filtroEscolhido);
    if (caminho.isEmpty())
        return;

    // .csv = planilha com colunas e totais; .txt = uma linha por reserva (formatarExportacao)
    if (caminho.endsWith(".txt", Qt::CaseInsensitive)) {
        QFile arquivo(caminho);
        if (!arquivo.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QMessageBox::warning(this, tr("Exportar"), tr("Não foi possível salvar o arquivo."));
            return;
        }
        QTextStream saida(&arquivo);
        saida.setEncoding(QStringConverter::Utf8);
        saida.setGenerateByteOrderMark(true);
        for (const QString &linha : Sistema::instancia().exportarReservas())
            saida << linha << '\n';
    } else {
        QString erro;
        if (!Sistema::instancia().exportarPlanilha(caminho, &erro)) {
            QMessageBox::warning(this, tr("Exportar"), erro);
            return;
        }
    }
    QMessageBox::information(this, tr("Exportar"), tr("Arquivo salvo com sucesso!"));
}

// Passo 11 do plano: lê um arquivo de reservas externas e mostra o que foi aceito ou deu conflito
void PaginaReservas::importar()
{
    const QString caminho = QFileDialog::getOpenFileName(
        this, tr("Importar reservas do Airbnb"), QString(), tr("Arquivos de reservas (*.txt *.csv)"));
    if (caminho.isEmpty())
        return;

    const ResultadoImportacaoInfo r = Sistema::instancia().importarReservas(caminho);
    if (!r.erro.isEmpty()) {
        QMessageBox::warning(this, tr("Importar"), r.erro);
        return;
    }
    QString detalhes;
    if (!r.aceitas.isEmpty())
        detalhes += tr("ACEITAS:\n") + r.aceitas.join("\n") + "\n\n";
    if (!r.conflitos.isEmpty())
        detalhes += tr("CONFLITOS (overbooking):\n") + r.conflitos.join("\n") + "\n\n";
    if (!r.invalidas.isEmpty())
        detalhes += tr("INVÁLIDAS:\n") + r.invalidas.join("\n");

    QMessageBox caixa(this);
    caixa.setWindowTitle(tr("Importação concluída"));
    caixa.setIcon(r.conflitos.isEmpty() && r.invalidas.isEmpty() ? QMessageBox::Information
                                                                  : QMessageBox::Warning);
    caixa.setText(tr("%1 aceita(s), %2 com conflito, %3 inválida(s).")
                      .arg(r.aceitas.size())
                      .arg(r.conflitos.size())
                      .arg(r.invalidas.size()));
    caixa.setDetailedText(detalhes.trimmed());
    caixa.exec();
}
