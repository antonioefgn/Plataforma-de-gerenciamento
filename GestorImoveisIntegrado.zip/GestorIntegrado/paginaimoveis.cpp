#include "paginaimoveis.h"
#include "ui_paginaimoveis.h"

#include <QDateTime>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QHeaderView>
#include <QMessageBox>

#include "sistema.h"

PaginaImoveis::PaginaImoveis(QWidget *parent) : QWidget(parent), ui(new Ui::PaginaImoveis)
{
    ui->setupUi(this);
    ui->tabelaImoveis->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->splitter->setStretchFactor(0, 2);
    ui->splitter->setStretchFactor(1, 3);

    connect(ui->btnNovoImovel, &QPushButton::clicked, this, [this] { novo(); });
    connect(ui->btnSalvarImovel, &QPushButton::clicked, this, [this] { salvar(); });
    connect(ui->btnExcluirImovel, &QPushButton::clicked, this, [this] { excluir(); });
    connect(ui->btnImportarFoto, &QPushButton::clicked, this, [this] { importarFoto(); });
    connect(ui->btnRemoverFoto, &QPushButton::clicked, this, [this] { removerFoto(); });
    connect(ui->tabelaImoveis, &QTableWidget::itemSelectionChanged, this, [this] { aoSelecionar(); });
    connect(&Sistema::instancia(), &Sistema::dadosAlterados, this, [this] { atualizarLista(); });

    atualizarLista();
}

PaginaImoveis::~PaginaImoveis()
{
    delete ui;
}

void PaginaImoveis::resizeEvent(QResizeEvent *e)
{
    QWidget::resizeEvent(e);
    ui->splitter->setOrientation(width() < 860 ? Qt::Vertical : Qt::Horizontal);
}

void PaginaImoveis::atualizarLista()
{
    const QList<ImovelInfo> lista = Sistema::instancia().imoveis();
    QTableWidget *t = ui->tabelaImoveis;
    t->blockSignals(true);
    t->setRowCount(lista.size());
    int linhaAtual = -1;
    for (int r = 0; r < lista.size(); ++r) {
        const ImovelInfo &i = lista[r];
        auto *nome = new QTableWidgetItem(i.titulo);
        nome->setData(Qt::UserRole, i.id);
        auto *diaria = new QTableWidgetItem(moeda(i.diaria));
        diaria->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        auto *cap = new QTableWidgetItem(QString::number(i.capacidade));
        cap->setTextAlignment(Qt::AlignCenter);
        t->setItem(r, 0, nome);
        t->setItem(r, 1, diaria);
        t->setItem(r, 2, cap);
        if (i.id == m_idAtual)
            linhaAtual = r;
    }
    if (linhaAtual >= 0)
        t->selectRow(linhaAtual);
    else
        t->clearSelection();
    t->blockSignals(false);
}

void PaginaImoveis::aoSelecionar()
{
    const auto itens = ui->tabelaImoveis->selectedItems();
    if (itens.isEmpty())
        return;
    carregarFormulario(ui->tabelaImoveis->item(itens.first()->row(), 0)->data(Qt::UserRole).toInt());
}

void PaginaImoveis::carregarFormulario(int id)
{
    const ImovelInfo i = Sistema::instancia().imovel(id);
    if (i.id == 0)
        return;
    m_idAtual = i.id;
    ui->editNomeImovel->setText(i.titulo);
    ui->editEndereco->setText(i.endereco);
    ui->editDescricao->setPlainText(i.descricao);
    ui->spinDiaria->setValue(i.diaria);
    ui->spinCapacidade->setValue(i.capacidade);
    m_foto = i.foto;
    ui->fotoImovel->setImagePath(m_foto);
}

void PaginaImoveis::limparFormulario()
{
    m_idAtual = 0;
    ui->editNomeImovel->clear();
    ui->editEndereco->clear();
    ui->editDescricao->clear();
    ui->spinDiaria->setValue(0);
    ui->spinCapacidade->setValue(1);
    m_foto.clear();
    ui->fotoImovel->setImagePath({});
}

void PaginaImoveis::novo()
{
    ui->tabelaImoveis->clearSelection();
    limparFormulario();
    ui->editNomeImovel->setFocus();
}

void PaginaImoveis::salvar()
{
    if (ui->editNomeImovel->text().trimmed().isEmpty()) {
        QMessageBox::warning(this, tr("Imóvel"), tr("Informe o nome do imóvel."));
        ui->editNomeImovel->setFocus();
        return;
    }
    if (ui->spinDiaria->value() <= 0) {
        QMessageBox::warning(this, tr("Imóvel"), tr("Informe o valor da diária."));
        ui->spinDiaria->setFocus();
        return;
    }
    ImovelInfo i;
    i.id = m_idAtual;
    i.titulo = ui->editNomeImovel->text().trimmed();
    i.endereco = ui->editEndereco->text().trimmed();
    i.descricao = ui->editDescricao->toPlainText().trimmed();
    i.diaria = ui->spinDiaria->value();
    i.capacidade = ui->spinCapacidade->value();
    i.foto = m_foto;

    const bool eraNovo = (i.id == 0);
    m_idAtual = Sistema::instancia().salvarImovel(i);
    if (eraNovo)
        atualizarLista(); // seleciona o imóvel recém-criado na tabela
    QMessageBox::information(this, tr("Imóvel"), tr("Imóvel salvo com sucesso!"));
}

void PaginaImoveis::excluir()
{
    if (m_idAtual == 0) {
        QMessageBox::information(this, tr("Imóvel"), tr("Selecione um imóvel na lista."));
        return;
    }
    const auto r = QMessageBox::question(
        this, tr("Excluir imóvel"),
        tr("Excluir este imóvel e TODAS as reservas dele? Esta ação não pode ser desfeita."));
    if (r != QMessageBox::Yes)
        return;
    const int id = m_idAtual;
    limparFormulario();
    Sistema::instancia().excluirImovel(id);
}

void PaginaImoveis::importarFoto()
{
    const QString origem = QFileDialog::getOpenFileName(
        this, tr("Escolher foto do imóvel"), QString(),
        tr("Imagens (*.png *.jpg *.jpeg *.bmp *.webp)"));
    if (origem.isEmpty())
        return;

    // Copia a foto para a pasta do programa, para ela não sumir se o original for movido
    const QString destino = Sistema::instancia().pastaDeDados() + "/fotos/"
                            + QString::number(QDateTime::currentMSecsSinceEpoch()) + "_"
                            + QFileInfo(origem).fileName();
    if (!QFile::copy(origem, destino)) {
        QMessageBox::warning(this, tr("Foto"), tr("Não foi possível importar a foto."));
        return;
    }
    m_foto = destino;
    ui->fotoImovel->setImagePath(m_foto);
}

void PaginaImoveis::removerFoto()
{
    m_foto.clear();
    ui->fotoImovel->setImagePath({});
}
