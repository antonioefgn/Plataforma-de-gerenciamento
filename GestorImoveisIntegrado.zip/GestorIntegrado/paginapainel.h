#pragma once

#include <QWidget>

namespace Ui { class PaginaPainel; }

// Painel geral: números do negócio e próximos check-ins/check-outs.
class PaginaPainel : public QWidget {
public:
    explicit PaginaPainel(QWidget *parent = nullptr);
    ~PaginaPainel() override;

private:
    void atualizar();

    Ui::PaginaPainel *ui;
};
