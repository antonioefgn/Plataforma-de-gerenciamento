// Teste das classes da equipe (C++ puro, sem Qt).
// Compilar e rodar, a partir da pasta do projeto:
//   g++ -std=c++17 -Wall -Wextra -Wpedantic -Iclasses testes/teste_classes.cpp -o teste_classes
//   ./teste_classes            (no Windows: teste_classes.exe)
#include <cstdio>
#include <fstream>
#include <sstream>
#include <memory>
#include "gerenciador_canais.hpp"

static int falhas = 0;
#define CHECK(cond)                                                                   \
    do {                                                                              \
        if (!(cond)) { std::printf("  FALHOU (linha %d): %s\n", __LINE__, #cond); ++falhas; } \
        else         { std::printf("  ok: %s\n", #cond); }                            \
    } while (0)

template <typename Excecao, typename F>
static bool lanca(F f) {
    try { f(); } catch (const Excecao&) { return true; } catch (...) { return false; }
    return false;
}

static GerenciadorCanais criarGerenciador() {
    GerenciadorCanais g;
    g.adicionarPlataforma(std::make_unique<ReservaDireta>());
    g.adicionarPlataforma(std::make_unique<Airbnb>());
    g.adicionarPlataforma(std::make_unique<Booking>());
    g.adicionarImovel(Imovel(1, "Casa de praia", 300.0));
    g.adicionarImovel(Imovel(2, "Apto centro", 200.0));
    return g;
}

static Reserva res(const char* in, const char* out, const char* plat, float bruto, const char* nome = "Maria") {
    return Reserva(Data::de_texto(in), Data::de_texto(out), Hospede(nome, "111", "8399", "m@x.com"), bruto, plat);
}

int main() {
    std::printf("[Passo 2/13] Data\n");
    CHECK(lanca<std::invalid_argument>([] { Data(31, 2, 2026); }));
    CHECK(lanca<std::invalid_argument>([] { Data(29, 2, 2027); }));
    CHECK(!lanca<std::invalid_argument>([] { Data(29, 2, 2028); }));  // ano bissexto
    CHECK(lanca<std::invalid_argument>([] { Data::de_texto("2026-01-10"); }));
    CHECK(Data(28, 11, 2026).diasAte(Data(2, 12, 2026)) == 4);
    CHECK(Data(28, 2, 2028).diasAte(Data(1, 3, 2028)) == 2);          // 29/02 existe
    CHECK(Data(1, 1, 2026) < Data(2, 1, 2026) && Data(1, 1, 2026) <= Data(1, 1, 2026));
    CHECK(Data(2, 1, 2026) > Data(1, 1, 2026) && Data(1, 1, 2026) >= Data(1, 1, 2026) && Data(1, 1, 2026) == Data(1, 1, 2026));

    std::printf("[Passo 3] Reserva::conflitaCom\n");
    const Reserva a = res("10/01/2027", "15/01/2027", "Airbnb", 1500);
    CHECK(a.conflitaCom(res("12/01/2027", "18/01/2027", "Booking", 100)));
    CHECK(!a.conflitaCom(res("15/01/2027", "18/01/2027", "Booking", 100)));  // troca no mesmo dia
    CHECK(!a.conflitaCom(res("05/01/2027", "10/01/2027", "Booking", 100)));
    CHECK(a.get_noites() == 5);
    CHECK(lanca<std::invalid_argument>([] { res("15/01/2027", "10/01/2027", "Airbnb", 100); }));
    CHECK(lanca<std::invalid_argument>([] { res("10/01/2027", "15/01/2027", "Airbnb", -1); }));

    std::printf("[Passo 8] registrarReserva + sincronizacao\n");
    GerenciadorCanais g = criarGerenciador();
    std::ostringstream console;
    auto avisos = g.registrarReserva(1, a, g.buscarPlataforma("Airbnb"), console);
    CHECK(avisos.size() == 2);                                   // Booking e Reserva Direta
    CHECK(console.str().find("Booking") != std::string::npos && console.str().find("Reserva Direta") != std::string::npos);
    CHECK(console.str().find("Airbnb (imovel") == std::string::npos);  // nao avisa a propria origem
    CHECK(lanca<std::runtime_error>([&] { g.registrarReserva(1, res("12/01/2027", "18/01/2027", "Booking", 900), g.buscarPlataforma("Booking"), console); }));
    CHECK(lanca<std::invalid_argument>([&] { g.registrarReserva(99, res("01/03/2027", "05/03/2027", "Airbnb", 900), g.buscarPlataforma("Airbnb"), console); }));
    CHECK(lanca<std::invalid_argument>([&] { g.registrarReserva(1, res("01/03/2027", "05/03/2027", "Airbnb", 900), nullptr, console); }));
    CHECK(lanca<std::invalid_argument>([&] { g.registrarReserva(1, res("01/03/2027", "05/03/2027", "Airbnb", 900), g.buscarPlataforma("Booking"), console); }));
    g.registrarReserva(1, res("15/01/2027", "20/01/2027", "Booking", 1000, "Joao"), g.buscarPlataforma("Booking"), console);
    g.registrarReserva(2, res("01/02/2027", "04/02/2027", "Reserva Direta", 600, "Ana"), g.buscarPlataforma("Reserva Direta"), console);

    std::printf("[Passo 9] Faturamento\n");
    const Faturamento f1 = g.faturamentoPorImovel(1);
    CHECK(f1.reservas == 2 && f1.bruto == 2500.0);
    CHECK(std::abs(f1.liquido - (1500 * 0.85 + (1000 * 0.88 - 80))) < 0.01);
    CHECK(std::abs(g.faturamentoPorPlataforma("Airbnb").liquido - 1275.0) < 0.01);
    CHECK(std::abs(g.faturamentoPorPlataforma("Booking").liquido - 800.0) < 0.01);
    CHECK(std::abs(g.faturamentoPorPlataforma("Reserva Direta").liquido - 600.0) < 0.01);
    CHECK(g.faturamentoTotal().reservas == 3 && g.faturamentoTotal().bruto == 3100.0);
    CHECK(lanca<std::invalid_argument>([&] { g.faturamentoPorImovel(99); }));
    CHECK(lanca<std::invalid_argument>([&] { g.faturamentoPorPlataforma("Decolar"); }));
    std::printf("\n%s\n", g.relatorioFinanceiro().c_str());

    std::printf("[Passo 10] CSV (arquivos reais com fstream)\n");
    g.salvarCsv("/tmp/imoveis.csv", "/tmp/reservas.csv");
    GerenciadorCanais g2;
    g2.adicionarPlataforma(std::make_unique<ReservaDireta>());
    g2.adicionarPlataforma(std::make_unique<Airbnb>());
    g2.adicionarPlataforma(std::make_unique<Booking>());
    const auto avisosCarga = g2.carregarCsv("/tmp/imoveis.csv", "/tmp/reservas.csv");
    CHECK(avisosCarga.empty());
    CHECK(g2.get_imoveis().size() == 2);
    CHECK(g2.faturamentoTotal().reservas == 3 && std::abs(g2.faturamentoTotal().liquido - g.faturamentoTotal().liquido) < 0.01);
    CHECK(lanca<std::runtime_error>([&] { g2.carregarCsv("/tmp/nao_existe.csv", "/tmp/reservas.csv"); }));
    std::istringstream ruim("1;32/13/2027;02/01/2027;X;1;2;3;100;Airbnb\n99;01/01/2027;03/01/2027;X;1;2;3;100;Airbnb\nlixo\n");
    CHECK(g2.carregarReservasCsv(ruim).size() == 3);  // data invalida, imovel inexistente, campos faltando

    std::printf("[Passo 11] Importacao de arquivo\n");
    GerenciadorCanais g3 = criarGerenciador();
    std::ostringstream descarte;
    const ResultadoImportacao ri = g3.importarReservasDeArquivo("exemplos/novas_reservas_airbnb.txt", "Airbnb", descarte);
    CHECK(ri.aceitas.size() == 2 && ri.conflitos.size() == 1 && ri.invalidas.empty());
    CHECK(ri.reservasAceitas.size() == 2);
    std::istringstream mista("99;01/01/2027;03/01/2027;X;1;2;3;100\n1;31/02/2027;03/03/2027;X;1;2;3;100\n");
    const ResultadoImportacao rm = g3.importarReservas(mista, "Airbnb", descarte);
    CHECK(rm.invalidas.size() == 2);
    CHECK(lanca<std::runtime_error>([&] { g3.importarReservasDeArquivo("/tmp/nao_existe.txt", "Airbnb", descarte); }));
    CHECK(lanca<std::invalid_argument>([&] { g3.importarReservasDeArquivo("exemplos/novas_reservas_airbnb.txt", "Decolar", descarte); }));

    std::printf("[Planilha] exportarPlanilha\n");
    std::ostringstream planilha;
    g.exportarPlanilha(planilha);
    const std::string p = planilha.str();
    CHECK(p.compare(0, 3, "\xEF\xBB\xBF") == 0);
    CHECK(p.find("TOTAL;;;;;;;") != std::string::npos);
    CHECK(p.find("1500,00;1275,00") != std::string::npos);  // virgula decimal
    g.exportarPlanilhaParaArquivo("/tmp/planilha.csv");
    std::printf("\n%s\n", p.c_str());

    std::printf("\n%s (%d falha(s))\n", falhas == 0 ? "TUDO OK" : "HA FALHAS", falhas);
    return falhas == 0 ? 0 : 1;
}
