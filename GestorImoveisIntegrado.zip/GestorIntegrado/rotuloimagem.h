#pragma once

#include <QFileInfo>
#include <QLabel>
#include <QPixmap>
#include <QResizeEvent>

// QLabel que redimensiona a foto automaticamente, mantendo a proporção.
// É usado na tela de imóveis (aparece no Designer como "widget promovido").
class RotuloImagem : public QLabel {
public:
    explicit RotuloImagem(QWidget *parent = nullptr) : QLabel(parent)
    {
        setAlignment(Qt::AlignCenter);
        setMinimumSize(1, 1);
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    }

    void setImagePath(const QString &caminho)
    {
        m_pixmap = QPixmap();
        if (!caminho.isEmpty() && QFileInfo::exists(caminho))
            m_pixmap.load(caminho);
        atualizar();
    }

    QSize sizeHint() const override { return QSize(280, 200); }
    QSize minimumSizeHint() const override { return QSize(120, 90); }

protected:
    void resizeEvent(QResizeEvent *e) override
    {
        QLabel::resizeEvent(e);
        atualizar();
    }

private:
    void atualizar()
    {
        if (m_pixmap.isNull()) {
            clear();
            setText(tr("Sem foto\n(clique em \"Importar foto\")"));
            return;
        }
        setPixmap(m_pixmap.scaled(size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
    }

    QPixmap m_pixmap;
};
