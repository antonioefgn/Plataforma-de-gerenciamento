#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "paginareservas.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Menu lateral: navegar entre as telas (necessário para visualizar o esqueleto)
    m_itens = {{ui->btnPainel, "📊", tr("Painel")},
               {ui->btnImoveis, "🏘", tr("Imóveis")},
               {ui->btnCalendario, "📅", tr("Calendário / Reservas")},
               {ui->btnClientes, "👥", tr("Clientes")},
               {ui->btnRelatorios, "📈", tr("Relatórios")}};
    for (int i = 0; i < m_itens.size(); ++i)
        connect(m_itens[i].botao, &QPushButton::clicked, this,
                [this, i] { ui->paginas->setCurrentIndex(i); });

    // "Novo cliente" na tela de reservas leva direto para a tela de clientes
    connect(ui->paginaReservas, &PaginaReservas::irParaClientes, this,
            [this] { ui->btnClientes->click(); });

    connect(ui->btnSair, &QPushButton::clicked, this, [this] {
        m_logout = true;
        close();
    });

    m_itens.first().botao->setChecked(true);
    aplicarModoCompacto(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// Janela estreita: o menu lateral vira uma barra só com ícones
void MainWindow::aplicarModoCompacto(bool compacto)
{
    m_compacto = compacto;
    for (const auto &it : std::as_const(m_itens)) {
        it.botao->setText(compacto ? it.icone : it.icone + "  " + it.texto);
        it.botao->setToolTip(it.texto);
    }
    ui->logoMenu->setText(compacto ? "🏠" : tr("🏠 Gestor"));
    ui->btnSair->setText(compacto ? "🚪" : tr("🚪  Sair"));
    ui->btnSair->setToolTip(tr("Sair"));
    ui->menuLateral->setFixedWidth(compacto ? 64 : 230);
}

void MainWindow::resizeEvent(QResizeEvent *e)
{
    QMainWindow::resizeEvent(e);
    const bool compacto = width() < 900;
    if (compacto != m_compacto)
        aplicarModoCompacto(compacto);
}
