#pragma once

#include <QWidget>

namespace Ui { class PaginaRelatorios; }

// Relatório financeiro: valor bruto e líquido por imóvel, por plataforma e total.
// Os números vêm do GerenciadorCanais (passo 9 do plano), via classe Sistema.
class PaginaRelatorios : public QWidget {
public:
    explicit PaginaRelatorios(QWidget *parent = nullptr);
    ~PaginaRelatorios() override;

protected:
    void resizeEvent(QResizeEvent *e) override;

private:
    void atualizar();

    Ui::PaginaRelatorios *ui;
};
