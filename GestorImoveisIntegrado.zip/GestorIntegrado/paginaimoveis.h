#pragma once

#include <QString>
#include <QWidget>

namespace Ui { class PaginaImoveis; }

// Tela de imóveis: lista + formulário (nome, endereço, diária, capacidade, descrição, foto).
// Os dados vêm e vão pela classe Sistema.
class PaginaImoveis : public QWidget {
public:
    explicit PaginaImoveis(QWidget *parent = nullptr);
    ~PaginaImoveis() override;

protected:
    void resizeEvent(QResizeEvent *e) override;

private:
    void atualizarLista();
    void aoSelecionar();
    void carregarFormulario(int id);
    void limparFormulario();
    void novo();
    void salvar();
    void excluir();
    void importarFoto();
    void removerFoto();

    Ui::PaginaImoveis *ui;
    int m_idAtual = 0; // 0 = imóvel novo
    QString m_foto;
};
