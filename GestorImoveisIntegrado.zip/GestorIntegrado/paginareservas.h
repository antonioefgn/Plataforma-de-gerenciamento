#pragma once

#include <QDate>
#include <QWidget>

namespace Ui { class PaginaReservas; }

// Tela de calendário e reservas. O usuário escolhe entre:
//   - "Ver dias alugados": calendário pintado + tabela de reservas do imóvel;
//   - "Registrar novo aluguel": formulário (hóspede, datas, plataforma).
class PaginaReservas : public QWidget {
    Q_OBJECT
public:
    explicit PaginaReservas(QWidget *parent = nullptr);
    ~PaginaReservas() override;

signals:
    void irParaClientes(); // botão "Novo cliente"

protected:
    void resizeEvent(QResizeEvent *e) override;

private:
    int imovelAtual() const;
    void atualizarCombos();
    void aoMudarImovel();
    void aoMudarModo();
    void aoClicarData(const QDate &data);
    void aoMudarDatas();
    void atualizarTotais();
    void preencherTabela();
    void atualizarCalendario();
    void mostrarResumoDia(const QDate &data);
    void registrar();
    void limparFormulario();
    void excluirReserva();
    void exportar();
    void importar();

    Ui::PaginaReservas *ui;
    bool m_atualizando = false;
    bool m_aguardandoSaida = false;
};
