#pragma once

#include <QString>
#include <QWidget>

namespace Ui { class PaginaClientes; }

// Tela de clientes (hóspedes): nome, documento, telefone e e-mail.
// O documento identifica o cliente e não pode se repetir.
class PaginaClientes : public QWidget {
public:
    explicit PaginaClientes(QWidget *parent = nullptr);
    ~PaginaClientes() override;

protected:
    void resizeEvent(QResizeEvent *e) override;

private:
    void atualizarLista();
    void aoSelecionar();
    void carregarFormulario(const QString &documento);
    void limparFormulario();
    void novo();
    void salvar();
    void excluir();

    Ui::PaginaClientes *ui;
    QString m_docAtual; // vazio = cliente novo
};
