#pragma once

#include <QList>
#include <QMainWindow>

class QPushButton;

namespace Ui { class MainWindow; }

class MainWindow : public QMainWindow {
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;
    bool logoutSolicitado() const { return m_logout; }

protected:
    void resizeEvent(QResizeEvent *e) override;

private:
    void aplicarModoCompacto(bool compacto);

    struct Item {
        QPushButton *botao;
        QString icone;
        QString texto;
    };

    Ui::MainWindow *ui;
    QList<Item> m_itens;
    bool m_compacto = false;
    bool m_logout = false;
};
