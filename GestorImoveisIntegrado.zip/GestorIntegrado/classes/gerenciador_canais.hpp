#ifndef GERENCIADOR_CANAIS_HPP
#define GERENCIADOR_CANAIS_HPP

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <locale>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#include "imovel.hpp"
#include "plataforma.hpp"

// [PASSO 9] Totais financeiros de um imovel, de uma plataforma ou do sistema inteiro.
struct Faturamento {
    double bruto = 0.0;
    double liquido = 0.0;
    int reservas = 0;
};

// [PASSO 11] Resultado da importacao de reservas de um arquivo.
struct ResultadoImportacao {
    std::vector<std::string> aceitas;
    std::vector<std::string> conflitos;  // overbooking: ja existe reserva nessas datas
    std::vector<std::string> invalidas;  // linha mal formatada, data invalida, imovel inexistente...
    std::vector<Reserva> reservasAceitas;
};

class GerenciadorCanais {
    std::vector<Imovel> imoveis;
    std::vector<std::unique_ptr<Plataforma>> plataformas;

    // ------------------------------------------------------------------
    // Utilitarios internos de texto/CSV (usados nos passos 10, 11 e na planilha)
    // ------------------------------------------------------------------

    // Remove ';' e quebras de linha de um texto, para nao quebrar o CSV
    static std::string limpar(const std::string& s) {
        std::string r = s;
        for (char& c : r)
            if (c == ';' || c == '\n' || c == '\r') c = ' ';
        return r;
    }

    static std::string aparar(const std::string& s) {
        const char* espacos = " \t\r\n";
        const auto ini = s.find_first_not_of(espacos);
        if (ini == std::string::npos) return "";
        const auto fim = s.find_last_not_of(espacos);
        return s.substr(ini, fim - ini + 1);
    }

    // Divide uma linha pelo ';' mantendo os campos vazios
    static std::vector<std::string> dividir(const std::string& linha) {
        std::vector<std::string> campos;
        std::string atual;
        for (char c : linha) {
            if (c == ';') { campos.push_back(aparar(atual)); atual.clear(); }
            else atual += c;
        }
        campos.push_back(aparar(atual));
        return campos;
    }

    // Numeros sempre com ponto decimal, independente da configuracao do computador
    static std::string numero(double v) {
        std::ostringstream oss;
        oss.imbue(std::locale::classic());
        oss << std::fixed << std::setprecision(2) << v;
        return oss.str();
    }

    static double lerNumero(const std::string& s) {
        std::istringstream iss(s);
        iss.imbue(std::locale::classic());
        double v = 0.0;
        if (!(iss >> v)) throw std::invalid_argument("Numero invalido: " + s);
        return v;
    }

    static int lerInteiro(const std::string& s) {
        try {
            return std::stoi(s);
        } catch (const std::exception&) {
            throw std::invalid_argument("Numero inteiro invalido: " + s);
        }
    }

    bool plataformaRegistrada(const Plataforma* p) const {
        return std::any_of(plataformas.begin(), plataformas.end(),
            [&](const auto& x) { return x.get() == p; });
    }

    // Valor liquido de uma reserva, usando o polimorfismo da plataforma dela
    double liquidoDe(const Reserva& r) const {
        const Plataforma* p = buscarPlataforma(r.get_nome_plataforma());
        return p ? p->calcularValorLiquido(r.get_valor_bruto()) : r.get_valor_bruto();
    }

    // Converte uma linha de campos em Reserva.
    // Formato: id_imovel;check_in;check_out;nome;documento;telefone;email;valor_bruto[;plataforma]
    Reserva lerReserva(const std::vector<std::string>& c, int& idImovel,
                       const std::string& plataformaPadrao) const {
        if (c.size() < 8)
            throw std::invalid_argument(
                "Campos faltando (esperado: id_imovel;check_in;check_out;nome;documento;telefone;email;valor_bruto)");
        idImovel = lerInteiro(c[0]);
        const std::string plataforma = (c.size() >= 9 && !c[8].empty()) ? c[8] : plataformaPadrao;
        if (!buscarPlataforma(plataforma))
            throw std::invalid_argument("Plataforma desconhecida: '" + plataforma + "'");
        return Reserva(Data::de_texto(c[1]), Data::de_texto(c[2]),
                       Hospede(c[3], c[4], c[5], c[6]),
                       static_cast<float>(lerNumero(c[7])), plataforma);
    }

public:
    void adicionarImovel(const Imovel& imovel) {
        if (buscarImovel(imovel.get_id()))
            throw std::runtime_error("Ja existe imovel com id " + std::to_string(imovel.get_id()));
        imoveis.push_back(imovel);
    }

    void adicionarPlataforma(std::unique_ptr<Plataforma> p) {
        if (!p) throw std::invalid_argument("Plataforma nula");
        plataformas.push_back(std::move(p));
    }

    Imovel* buscarImovel(int id) {
        auto it = std::find_if(imoveis.begin(), imoveis.end(),
            [id](const Imovel& i) { return i.get_id() == id; });
        return it != imoveis.end() ? &*it : nullptr;
    }

    // [PASSO 14] versao const, para metodos de leitura (relatorios, exportacao)
    const Imovel* buscarImovel(int id) const {
        auto it = std::find_if(imoveis.begin(), imoveis.end(),
            [id](const Imovel& i) { return i.get_id() == id; });
        return it != imoveis.end() ? &*it : nullptr;
    }

    const Plataforma* buscarPlataforma(const std::string& nome) const {
        auto it = std::find_if(plataformas.begin(), plataformas.end(),
            [&](const auto& p) { return p->get_nome() == nome; });
        return it != plataformas.end() ? it->get() : nullptr;
    }

    const std::vector<Imovel>& get_imoveis() const { return imoveis; }

    // ==================================================================
    // [PASSO 8] Registrar reserva + simulacao de sincronizacao
    // ==================================================================
    // Valida e salva a reserva no imovel. Em seguida simula o bloqueio das mesmas datas
    // nas OUTRAS plataformas: imprime um aviso em "saida" (console por padrao) e tambem
    // devolve os avisos, para a interface poder mostra-los.
    // Lanca: invalid_argument (imovel inexistente, origem invalida) e
    //        runtime_error (conflito de datas / overbooking).
    std::vector<std::string> registrarReserva(int idImovel, Reserva novaReserva,
                                              const Plataforma* origem,
                                              std::ostream& saida = std::cout) {
        if (!origem)
            throw std::invalid_argument("Plataforma de origem nula");
        if (!plataformaRegistrada(origem))
            throw std::invalid_argument("Plataforma de origem nao cadastrada no gerenciador");
        if (novaReserva.get_nome_plataforma() != origem->get_nome())
            throw std::invalid_argument("A reserva informa a plataforma '" + novaReserva.get_nome_plataforma()
                                        + "', mas a origem informada e '" + origem->get_nome() + "'");
        Imovel* imovel = buscarImovel(idImovel);
        if (!imovel)
            throw std::invalid_argument("Imovel inexistente: id " + std::to_string(idImovel));

        imovel->adicionarReserva(novaReserva);  // lanca runtime_error se houver conflito

        std::vector<std::string> avisos;
        for (const auto& p : plataformas) {
            if (p.get() == origem) continue;
            std::ostringstream oss;
            oss << "[SINCRONIZACAO] Reserva recebida via " << origem->get_nome() << ": bloqueando "
                << novaReserva.get_check_in() << " a " << novaReserva.get_check_out()
                << " no " << p->get_nome() << " (imovel " << imovel->get_id()
                << " - " << imovel->get_titulo() << ")";
            avisos.push_back(oss.str());
        }
        for (const auto& a : avisos) saida << a << '\n';
        return avisos;
    }

    // ==================================================================
    // [PASSO 9] Relatorios financeiros (bruto x liquido, usando polimorfismo)
    // ==================================================================
    Faturamento faturamentoPorImovel(int idImovel) const {
        const Imovel* im = buscarImovel(idImovel);
        if (!im) throw std::invalid_argument("Imovel inexistente: id " + std::to_string(idImovel));
        Faturamento f;
        for (const Reserva& r : im->get_reservas()) {
            f.bruto += r.get_valor_bruto();
            f.liquido += liquidoDe(r);
            ++f.reservas;
        }
        return f;
    }

    Faturamento faturamentoPorPlataforma(const std::string& nomePlataforma) const {
        if (!buscarPlataforma(nomePlataforma))
            throw std::invalid_argument("Plataforma inexistente: " + nomePlataforma);
        Faturamento f;
        for (const Imovel& im : imoveis)
            for (const Reserva& r : im.get_reservas())
                if (r.get_nome_plataforma() == nomePlataforma) {
                    f.bruto += r.get_valor_bruto();
                    f.liquido += liquidoDe(r);
                    ++f.reservas;
                }
        return f;
    }

    Faturamento faturamentoTotal() const {
        Faturamento f;
        for (const Imovel& im : imoveis)
            for (const Reserva& r : im.get_reservas()) {
                f.bruto += r.get_valor_bruto();
                f.liquido += liquidoDe(r);
                ++f.reservas;
            }
        return f;
    }

    // Texto pronto para imprimir no console ou mostrar na interface
    std::string relatorioFinanceiro() const {
        std::ostringstream oss;
        oss << std::fixed << std::setprecision(2);
        auto linha = [&](const std::string& nome, const Faturamento& f) {
            oss << "  " << nome << " | Reservas: " << f.reservas
                << " | Bruto: R$ " << f.bruto << " | Liquido: R$ " << f.liquido << '\n';
        };
        oss << "===== RELATORIO FINANCEIRO =====\nPor imovel:\n";
        for (const Imovel& im : imoveis)
            linha("[" + std::to_string(im.get_id()) + "] " + im.get_titulo(), faturamentoPorImovel(im.get_id()));
        oss << "Por plataforma:\n";
        for (const auto& p : plataformas)
            linha(p->get_nome(), faturamentoPorPlataforma(p->get_nome()));
        oss << "TOTAL:\n";
        linha("Geral", faturamentoTotal());
        return oss.str();
    }

    // ==================================================================
    // [PASSO 10] Persistencia em .csv (campos separados por ';')
    // ==================================================================
    // imoveis.csv  : id;titulo;preco_diaria
    // reservas.csv : id_imovel;check_in;check_out;nome;documento;telefone;email;valor_bruto;plataforma
    // Os metodos com std::ostream/std::istream fazem o trabalho; os que recebem nome de
    // arquivo (fstream) apenas abrem o arquivo e chamam os primeiros.

    void salvarImoveisCsv(std::ostream& out) const {
        out << "id;titulo;preco_diaria\n";
        for (const Imovel& i : imoveis)
            out << i.get_id() << ';' << limpar(i.get_titulo()) << ';' << numero(i.get_preco_diaria()) << '\n';
    }

    void salvarReservasCsv(std::ostream& out) const {
        out << "id_imovel;check_in;check_out;nome;documento;telefone;email;valor_bruto;plataforma\n";
        for (const Imovel& i : imoveis)
            for (const Reserva& r : i.get_reservas()) {
                const Hospede h = r.get_hospede();
                out << i.get_id() << ';' << r.get_check_in() << ';' << r.get_check_out() << ';'
                    << limpar(h.get_nome()) << ';' << limpar(h.get_documento()) << ';'
                    << limpar(h.get_telefone()) << ';' << limpar(h.get_email()) << ';'
                    << numero(r.get_valor_bruto()) << ';' << limpar(r.get_nome_plataforma()) << '\n';
            }
    }

    void salvarCsv(const std::string& arquivoImoveis, const std::string& arquivoReservas) const {
        std::ofstream fi(arquivoImoveis);
        if (!fi) throw std::runtime_error("Nao foi possivel gravar o arquivo: " + arquivoImoveis);
        salvarImoveisCsv(fi);
        std::ofstream fr(arquivoReservas);
        if (!fr) throw std::runtime_error("Nao foi possivel gravar o arquivo: " + arquivoReservas);
        salvarReservasCsv(fr);
    }

    // Carrega imoveis (adiciona aos ja existentes). Devolve avisos das linhas ignoradas.
    std::vector<std::string> carregarImoveisCsv(std::istream& in) {
        std::vector<std::string> avisos;
        std::string linha;
        int n = 0;
        while (std::getline(in, linha)) {
            ++n;
            linha = aparar(linha);
            if (linha.empty() || linha[0] == '#') continue;
            const auto c = dividir(linha);
            if (c[0] == "id") continue;  // cabecalho
            try {
                if (c.size() < 3) throw std::invalid_argument("campos faltando");
                adicionarImovel(Imovel(lerInteiro(c[0]), c[1], lerNumero(c[2])));
            } catch (const std::exception& e) {
                avisos.push_back("imoveis.csv, linha " + std::to_string(n) + ": " + e.what());
            }
        }
        return avisos;
    }

    // Carrega reservas (os imoveis precisam ter sido carregados antes).
    std::vector<std::string> carregarReservasCsv(std::istream& in) {
        std::vector<std::string> avisos;
        std::string linha;
        int n = 0;
        while (std::getline(in, linha)) {
            ++n;
            linha = aparar(linha);
            if (linha.empty() || linha[0] == '#') continue;
            const auto c = dividir(linha);
            if (c[0] == "id_imovel") continue;  // cabecalho
            try {
                int idImovel = 0;
                const Reserva r = lerReserva(c, idImovel, "");
                Imovel* im = buscarImovel(idImovel);
                if (!im) throw std::invalid_argument("Imovel inexistente: id " + std::to_string(idImovel));
                im->adicionarReserva(r);
            } catch (const std::exception& e) {
                avisos.push_back("reservas.csv, linha " + std::to_string(n) + ": " + e.what());
            }
        }
        return avisos;
    }

    std::vector<std::string> carregarCsv(const std::string& arquivoImoveis,
                                         const std::string& arquivoReservas) {
        std::ifstream fi(arquivoImoveis);
        if (!fi) throw std::runtime_error("Nao foi possivel abrir o arquivo: " + arquivoImoveis);
        std::vector<std::string> avisos = carregarImoveisCsv(fi);
        std::ifstream fr(arquivoReservas);
        if (!fr) throw std::runtime_error("Nao foi possivel abrir o arquivo: " + arquivoReservas);
        const auto avisosReservas = carregarReservasCsv(fr);
        avisos.insert(avisos.end(), avisosReservas.begin(), avisosReservas.end());
        return avisos;
    }

    // ==================================================================
    // [PASSO 11] Importacao de reservas de um arquivo (ex.: novas_reservas_airbnb.txt)
    // ==================================================================
    // Cada linha: id_imovel;check_in;check_out;nome;documento;telefone;email;valor_bruto
    // (linhas vazias e iniciadas por '#' sao ignoradas). Cada reserva e registrada pelo
    // registrarReserva(); o resultado separa aceitas, conflitos (overbooking) e invalidas.
    ResultadoImportacao importarReservas(std::istream& in, const std::string& nomePlataforma = "Airbnb",
                                         std::ostream& saida = std::cout) {
        const Plataforma* origem = buscarPlataforma(nomePlataforma);
        if (!origem) throw std::invalid_argument("Plataforma inexistente: " + nomePlataforma);

        ResultadoImportacao res;
        std::string linha;
        int n = 0;
        while (std::getline(in, linha)) {
            ++n;
            linha = aparar(linha);
            if (linha.empty() || linha[0] == '#') continue;
            const auto c = dividir(linha);
            if (c[0] == "id_imovel") continue;  // cabecalho
            const std::string resumo = "linha " + std::to_string(n) + ": " + linha;
            try {
                int idImovel = 0;
                const Reserva r = lerReserva(c, idImovel, nomePlataforma);
                registrarReserva(idImovel, r, origem, saida);
                res.aceitas.push_back(resumo);
                res.reservasAceitas.push_back(r);
            } catch (const std::runtime_error&) {
                res.conflitos.push_back(resumo + "  -> CONFLITO DE DATAS (overbooking)");
            } catch (const std::exception& e) {
                res.invalidas.push_back(resumo + "  -> " + e.what());
            }
        }
        return res;
    }

    ResultadoImportacao importarReservasDeArquivo(const std::string& arquivo,
                                                  const std::string& nomePlataforma = "Airbnb",
                                                  std::ostream& saida = std::cout) {
        std::ifstream f(arquivo);
        if (!f) throw std::runtime_error("Nao foi possivel abrir o arquivo: " + arquivo);
        return importarReservas(f, nomePlataforma, saida);
    }

    // ==================================================================
    // Exportacao para planilha (abre direto no Excel em portugues: ';' e virgula decimal)
    // ==================================================================
    void exportarPlanilha(std::ostream& out) const {
        auto br = [](std::string s) {  // 1234.50 -> 1234,50
            std::replace(s.begin(), s.end(), '.', ',');
            return s;
        };
        out << "\xEF\xBB\xBF";  // marca UTF-8 (BOM) para o Excel acertar os acentos
        out << "Imovel;Hospede;Documento;Telefone;E-mail;Check-in;Check-out;Noites;"
               "Plataforma;Valor bruto;Valor liquido\n";
        double bruto = 0.0, liquido = 0.0;
        int noites = 0;
        for (const Imovel& i : imoveis)
            for (const Reserva& r : i.get_reservas()) {
                const Hospede h = r.get_hospede();
                const double l = liquidoDe(r);
                out << limpar(i.get_titulo()) << ';' << limpar(h.get_nome()) << ';'
                    << limpar(h.get_documento()) << ';' << limpar(h.get_telefone()) << ';'
                    << limpar(h.get_email()) << ';' << r.get_check_in() << ';' << r.get_check_out() << ';'
                    << r.get_noites() << ';' << limpar(r.get_nome_plataforma()) << ';'
                    << br(numero(r.get_valor_bruto())) << ';' << br(numero(l)) << '\n';
                bruto += r.get_valor_bruto();
                liquido += l;
                noites += r.get_noites();
            }
        out << "TOTAL;;;;;;;" << noites << ";;" << br(numero(bruto)) << ';' << br(numero(liquido)) << '\n';
    }

    void exportarPlanilhaParaArquivo(const std::string& arquivo) const {
        std::ofstream f(arquivo, std::ios::binary);
        if (!f) throw std::runtime_error("Nao foi possivel gravar o arquivo: " + arquivo);
        exportarPlanilha(f);
    }
};

#endif
