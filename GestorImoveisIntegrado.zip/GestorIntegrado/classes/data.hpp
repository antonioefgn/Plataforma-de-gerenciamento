#ifndef DATA_HPP
#define DATA_HPP

#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

using namespace std;

class Data {
private:
    int dia, mes, ano;

    int paraInteiro() const {
        return ano * 10000 + mes * 100 + dia;
    }

    // [PASSO 13] Numero de dias contados a partir de uma data de referencia.
    // Serve para calcular quantas noites existem entre duas datas.
    long paraDias() const {
        long a = ano, m = mes;
        if (m <= 2) { a -= 1; m += 12; }
        return 365 * a + a / 4 - a / 100 + a / 400 + (153 * (m - 3) + 2) / 5 + dia;
    }

public:
    // [PASSO 13] Validacao de datas
    static bool ehBissexto(int ano) {
        return (ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0);
    }

    static int diasNoMes(int mes, int ano) {
        static const int dias[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        if (mes == 2 && ehBissexto(ano)) return 29;
        return dias[mes - 1];
    }

    static bool valida(int dia, int mes, int ano) {
        return ano >= 1 && mes >= 1 && mes <= 12 && dia >= 1 && dia <= diasNoMes(mes, ano);
    }

    // Construtor padrão
    Data() : dia(1), mes(1), ano(2000) {}

    // Construtor parametrizado (lanca invalid_argument se a data nao existir, ex.: 31/02)
    Data(int dia, int mes, int ano) : dia(dia), mes(mes), ano(ano) {
        if (!valida(dia, mes, ano))
            throw invalid_argument("Data invalida: " + to_string(dia) + "/" + to_string(mes) + "/" + to_string(ano));
    }

    // [PASSO 10/11] Le uma data no formato dd/mm/aaaa (usado nos arquivos CSV e de importacao)
    static Data de_texto(const string& texto) {
        int d = 0, m = 0, a = 0;
        char s1 = 0, s2 = 0;
        istringstream iss(texto);
        if (!(iss >> d >> s1 >> m >> s2 >> a) || s1 != '/' || s2 != '/')
            throw invalid_argument("Data em formato invalido (use dd/mm/aaaa): " + texto);
        iss >> ws;
        if (!iss.eof())
            throw invalid_argument("Data em formato invalido (use dd/mm/aaaa): " + texto);
        return Data(d, m, a);
    }

    string para_texto() const {
        ostringstream oss;
        oss << *this;
        return oss.str();
    }

    // Numero de dias (noites) de esta data ate a outra. Negativo se a outra for anterior.
    int diasAte(const Data& outra) const {
        return static_cast<int>(outra.paraDias() - paraDias());
    }

    int get_dia() const { return dia; }
    int get_mes() const { return mes; }
    int get_ano() const { return ano; }

    // Os setters tambem validam. Para trocar a data inteira, prefira criar uma nova Data.
    void set_dia(int dia) {
        if (!valida(dia, mes, ano)) throw invalid_argument("Dia invalido: " + to_string(dia));
        this->dia = dia;
    }
    void set_mes(int mes) {
        if (!valida(dia, mes, ano)) throw invalid_argument("Mes invalido: " + to_string(mes));
        this->mes = mes;
    }
    void set_ano(int ano) {
        if (!valida(dia, mes, ano)) throw invalid_argument("Ano invalido: " + to_string(ano));
        this->ano = ano;
    }

    // Sobrecarga de operadores
    bool operator==(const Data& outra) const {
        return this->paraInteiro() == outra.paraInteiro();
    }

    bool operator!=(const Data& outra) const {
        return this->paraInteiro() != outra.paraInteiro();
    }

    bool operator<(const Data& outra) const {
        return this->paraInteiro() < outra.paraInteiro();
    }

    bool operator<=(const Data& outra) const {
        return this->paraInteiro() <= outra.paraInteiro();
    }

    bool operator>(const Data& outra) const {
        return this->paraInteiro() > outra.paraInteiro();
    }

    bool operator>=(const Data& outra) const {
        return this->paraInteiro() >= outra.paraInteiro();
    }

    // Sobrecarga do operador de saída (cout e arquivos)
    friend std::ostream& operator<<(std::ostream& os, const Data& d) {
        os << std::setfill('0') << std::setw(2) << d.dia << "/"
           << std::setfill('0') << std::setw(2) << d.mes << "/"
           << d.ano;
        return os;
    }
};

#endif
