#ifndef RESERVA_HPP
#define RESERVA_HPP

#include <stdexcept>
#include <string>
#include "data.hpp"
#include "hospede.hpp"

using namespace std;

class Reserva {
    private:
        Data check_in;
        Data check_out;
        Hospede hospede;
        float valor_bruto;
        string nome_plataforma;

    public:
        // [PASSO 13] Lanca invalid_argument se o check-out nao for depois do check-in
        // ou se o valor bruto for negativo.
        Reserva(Data check_in, Data check_out, Hospede hospede, float valor_bruto, string nome_plataforma){
            if (!(check_in < check_out))
                throw invalid_argument("O check-out deve ser depois do check-in");
            if (valor_bruto < 0.0f)
                throw invalid_argument("O valor bruto nao pode ser negativo");
            this->check_in = check_in;
            this->check_out = check_out;
            this->hospede = hospede;
            this->valor_bruto = valor_bruto;
            this->nome_plataforma = nome_plataforma;
        }

    // [PASSO 3] Nome e logica conforme o plano: (inicioA < fimB) && (fimA > inicioB).
    // Assim o check-out de uma reserva pode coincidir com o check-in de outra (troca no mesmo dia).
    bool conflitaCom(const Reserva& outra) const {
        return (this->check_in < outra.check_out) && (this->check_out > outra.check_in);
    }

    Data get_check_in() const { return check_in; }
    Data get_check_out() const { return check_out; }
    Hospede get_hospede() const { return hospede; }
    float get_valor_bruto() const { return valor_bruto; }
    string get_nome_plataforma() const { return nome_plataforma; }

    // Numero de noites da estadia
    int get_noites() const { return check_in.diasAte(check_out); }
};

#endif
