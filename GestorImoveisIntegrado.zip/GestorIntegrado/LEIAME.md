# Gestor de Imóveis (interface Qt + classes da equipe)

Login padrão: `admin` / `1234` (definido em `telalogin.cpp`).

## Como abrir
Extraia numa pasta **sem acentos, espaços ou parênteses** (ex.: `C:\projetos\GestorImoveis`),
abra o `CMakeLists.txt` no Qt Creator com um kit **Qt 6** e compile.

## Para revisar
1. `REVISAO_alteracoes_nas_classes.diff` mostra, linha a linha, tudo o que mudou nos arquivos de `classes/`
   (cada trecho novo tem um comentário `[PASSO n]`).
2. `testes/teste_classes.cpp` testa as classes **sem Qt**:
   `g++ -std=c++17 -Wall -Wextra -Wpedantic -Iclasses testes/teste_classes.cpp -o teste_classes` e rode `./teste_classes`.
3. `exemplos/novas_reservas_airbnb.txt` é o arquivo de teste do passo 11 (3 reservas: 2 aceitas e 1 overbooking;
   cadastre antes um imóvel de id 1).

## Plano de desenvolvimento x o que existe
| Passo | Onde está |
|---|---|
| 2 Data (operadores) | `classes/data.hpp` (+ validação de datas e cálculo de noites) |
| 3 Reserva / `conflitaCom` | `classes/reserva.hpp` (regra `(inicioA < fimB) && (fimA > inicioB)`) |
| 4, 5 Plataforma, Airbnb, Booking, ReservaDireta | `classes/plataforma.hpp` (sem alterações) |
| 6 Imovel | `classes/imovel.hpp` |
| 7 GerenciadorCanais | `classes/gerenciador_canais.hpp` |
| 8 `registrarReserva` + sincronização simulada | `GerenciadorCanais::registrarReserva`; na interface o aviso aparece na caixa de mensagem após registrar um aluguel |
| 9 Relatórios financeiros | `faturamentoPorImovel/PorPlataforma/Total`, `relatorioFinanceiro()`; na interface, a tela **Relatórios** |
| 10 CSV | `salvarCsv/carregarCsv` (+ versões com `ostream/istream`); o programa grava `imoveis.csv` e `reservas.csv` a cada alteração |
| 11 Importação | `importarReservas/importarReservasDeArquivo`; na interface, botão **Importar reservas** |
| 12 Menu | substituído pela interface gráfica (Imóveis, Reservas, Importar, Calendário, Relatórios) |
| 13 Exceções | `invalid_argument` (data inválida, imóvel inexistente, valores inválidos) e `runtime_error` (conflito) |
| 14 Revisão | destrutor virtual em `Plataforma`; compila sem avisos com `-Wall -Wextra -Wpedantic`; `buscarImovel` ganhou versão `const` |
| Extra: planilha | `exportarPlanilha` (CSV com `;`, vírgula decimal e linha de total; abre no Excel) |

## Como o projeto está organizado
| Parte | Arquivos | O que faz |
|---|---|---|
| Classes da equipe | `classes/*.hpp` | Modelo e regras de negócio. |
| Ponte | `sistema.h` / `sistema.cpp` | Única parte que usa as classes. Converte `std::string` <-> `QString`, `Data` <-> `QDate`, lê/grava os arquivos com `QFile` e guarda o que as classes não têm (`dados.json`). |
| Telas (`.ui` + `.cpp`) | `telalogin`, `mainwindow`, `paginapainel`, `paginaimoveis`, `paginareservas`, `paginaclientes`, `paginarelatorios` | Só conversam com a classe `Sistema`. |
| Widgets auxiliares | `rotuloimagem.h`, `calendarioreservas.h` | Foto que se ajusta ao tamanho e calendário pintado. |

Regra de ouro: as telas **não** incluem as classes da equipe. As classes têm `using namespace std;` nos headers;
por isso só o `sistema.cpp` as inclui.

## Onde ficam os dados
Na pasta de dados do aplicativo (`QStandardPaths::AppDataLocation`):
`imoveis.csv` e `reservas.csv` (classes da equipe), `dados.json` (endereço, foto, capacidade, descrição e lista de clientes) e a pasta `fotos/`.

## Ainda não coberto pelas classes (a interface contorna ou deixa de fora)
1. `Imovel` não tem endereço, capacidade, descrição nem foto -> guardados à parte no `Sistema` (`dados.json`).
2. `Reserva` não tem status (cancelada/concluída), pagamento, nº de hóspedes nem observações -> ficaram fora da tela.
3. Não há "remover"/"editar" em `Imovel` e `GerenciadorCanais` -> o `Sistema` recria os objetos sem o item removido.
4. `GerenciadorCanais` não lista as plataformas -> a lista está fixa no `sistema.cpp`.
5. `Reserva` guarda uma **cópia** do `Hospede`: editar um cliente não atualiza as reservas antigas dele.
6. `valor_bruto` é `float` e os cálculos das plataformas usam `double`.
7. Booking: a taxa de limpeza (R$ 80) é descontada do líquido de toda reserva.
8. Títulos, nomes etc. com `;` ou quebra de linha têm esses caracteres trocados por espaço ao gravar o CSV.
9. Dados gravados pela versão anterior deste projeto (que usava só JSON) não são lidos; comece com a pasta de dados limpa.
