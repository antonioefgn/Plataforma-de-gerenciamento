#include <QApplication>
#include <QStyleFactory>

#include "telalogin.h"
#include "mainwindow.h"

static const char *kEstilo = R"(
* { font-size: 10pt; }
QDialog#TelaLogin { background: #eef2f7; }
QFrame#loginCard { background: white; border-radius: 14px; border: 1px solid #d5dce6; }
QLabel#loginTitulo { font-size: 20pt; font-weight: bold; color: #1b3a5c; }
QLabel#loginSub { color: #7a8794; }
QLabel#erro { color: #c62828; }

QFrame#menuLateral { background: #1b3a5c; }
QLabel#logoMenu { color: white; font-size: 14pt; font-weight: bold; }
QPushButton[estilo="menu"], QPushButton[estilo="menuSec"] {
    color: #dbe7f3; background: transparent; border: none;
    text-align: left; padding: 10px 12px; border-radius: 8px;
}
QPushButton[estilo="menu"]:hover, QPushButton[estilo="menuSec"]:hover { background: #28507d; }
QPushButton[estilo="menu"]:checked { background: #2f6cb0; color: white; font-weight: bold; }

QLabel#tituloPagina { font-size: 18pt; font-weight: bold; color: #1b3a5c; }
QLabel[estilo="tituloSecao"] { font-size: 13pt; font-weight: bold; color: #1b3a5c; }

QFrame[estilo="card"] { background: white; border: 1px solid #d5dce6; border-radius: 10px; }
QLabel[estilo="cardTitulo"] { color: #7a8794; }
QLabel[estilo="cardValor"] { font-size: 20pt; font-weight: bold; color: #1b3a5c; }

QLabel#resumoDia { background: #f4f7fb; border-radius: 8px; padding: 8px; color: #2b3a4a; }
QLabel#fotoImovel { background: #f1f4f8; border: 2px dashed #b8c4d2; border-radius: 10px; color: #7a8794; }

QPushButton { padding: 7px 14px; border-radius: 6px; border: 1px solid #b8c4d2; background: #f7f9fc; }
QPushButton:hover { background: #e8eef6; }
QPushButton[estilo="primario"] { background: #2f6cb0; color: white; border: none; font-weight: bold; }
QPushButton[estilo="primario"]:hover { background: #26598f; }
QPushButton[estilo="perigo"] { color: #c62828; border: 1px solid #e0a3a3; }
QPushButton[estilo="perigo"]:hover { background: #fdecec; }

QLineEdit, QComboBox, QPlainTextEdit {
    padding: 5px; border: 1px solid #b8c4d2; border-radius: 6px; background: white;
}
QGroupBox { font-weight: bold; border: 1px solid #d5dce6; border-radius: 8px; margin-top: 10px; padding: 10px; }
QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 4px; }
QTableWidget { border: 1px solid #d5dce6; border-radius: 6px; gridline-color: #e6ebf1; }
QHeaderView::section { background: #eef2f7; border: none; padding: 6px; font-weight: bold; }
)";

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    app.setOrganizationName("GestorImoveis"); // usados para escolher a pasta dos dados
    app.setApplicationName("GestorImoveis");
    app.setStyle(QStyleFactory::create("Fusion"));
    app.setStyleSheet(kEstilo);

    // Login -> janela principal. "Sair" volta para o login.
    while (true) {
        TelaLogin login;
        if (login.exec() != QDialog::Accepted)
            break;
        MainWindow janela;
        janela.show();
        app.exec();
        if (!janela.logoutSolicitado())
            break;
    }
    return 0;
}
