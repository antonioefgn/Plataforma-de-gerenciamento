#include "sistema.h"

#include <algorithm>
#include <sstream>
#include <string>

#include <QDir>
#include <QFile>
#include <QHash>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLocale>
#include <QStandardPaths>

// As classes da equipe usam "using namespace std;" dentro dos headers.
// Por isso elas são incluídas por último e SOMENTE neste arquivo.
#include "classes/gerenciador_canais.hpp"
#include "classes/hospede.hpp"
#include "classes/plataforma.hpp"

// ---------- utilidades ----------

QString moeda(double valor)
{
    return QLocale(QLocale::Portuguese, QLocale::Brazil).toCurrencyString(valor);
}

QString dataBR(const QDate &d)
{
    return d.isValid() ? d.toString("dd/MM/yyyy") : QString();
}

namespace {

// Dados que as classes da equipe ainda não guardam (endereço, foto...)
struct Extras {
    QString endereco, descricao, foto;
    int capacidade = 1;
};

QDate paraQDate(const Data &d) { return QDate(d.get_ano(), d.get_mes(), d.get_dia()); }
Data paraData(const QDate &d) { return Data(d.day(), d.month(), d.year()); }

Hospede paraHospede(const HospedeInfo &h)
{
    return Hospede(h.nome.toStdString(), h.documento.toStdString(),
                   h.telefone.toStdString(), h.email.toStdString());
}

HospedeInfo deHospede(const Hospede &h)
{
    return {QString::fromStdString(h.get_nome()), QString::fromStdString(h.get_documento()),
            QString::fromStdString(h.get_telefone()), QString::fromStdString(h.get_email())};
}


// Leitura/escrita de arquivos com QFile (funciona com acentos no caminho, inclusive no Windows).
// As classes da equipe recebem/entregam os dados por std::istream / std::ostream.
std::string lerArquivo(const QString &caminho)
{
    QFile f(caminho);
    if (!f.open(QIODevice::ReadOnly))
        return {};
    const QByteArray bytes = f.readAll();
    return std::string(bytes.constData(), static_cast<size_t>(bytes.size()));
}

bool escreverArquivo(const QString &caminho, const std::string &texto)
{
    QFile f(caminho);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Truncate))
        return false;
    f.write(texto.data(), static_cast<qint64>(texto.size()));
    return true;
}

} // namespace

// ---------- dados internos ----------

struct DadosSistema {
    GerenciadorCanais ger;
    std::vector<Hospede> hospedes;
    QHash<int, Extras> extras;
    int proximoId = 1;
    const QStringList nomesPlataformas{"Reserva Direta", "Airbnb", "Booking"};

    static void configurar(GerenciadorCanais &g)
    {
        g.adicionarPlataforma(std::make_unique<ReservaDireta>());
        g.adicionarPlataforma(std::make_unique<Airbnb>());
        g.adicionarPlataforma(std::make_unique<Booking>());
    }

    DadosSistema() { configurar(ger); }

    double liquido(const QString &plataforma, double bruto) const
    {
        const Plataforma *p = ger.buscarPlataforma(plataforma.toStdString());
        return p ? p->calcularValorLiquido(bruto) : bruto;
    }

    ReservaInfo montar(int imovelId, int indice, const Reserva &r) const
    {
        ReservaInfo info;
        info.imovelId = imovelId;
        info.indice = indice;
        info.hospede = deHospede(r.get_hospede());
        info.checkIn = paraQDate(r.get_check_in());
        info.checkOut = paraQDate(r.get_check_out());
        info.plataforma = QString::fromStdString(r.get_nome_plataforma());
        info.bruto = r.get_valor_bruto();
        info.liquido = liquido(info.plataforma, info.bruto);
        return info;
    }
};

// ---------- Sistema ----------

Sistema::Sistema() : d(std::make_unique<DadosSistema>())
{
    carregarArquivo();
}

Sistema::~Sistema() = default;

Sistema &Sistema::instancia()
{
    static Sistema s;
    return s;
}

QString Sistema::pastaDeDados() const
{
    QString dir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    if (dir.isEmpty())
        dir = QDir::homePath() + "/.gestor_imoveis";
    QDir().mkpath(dir + "/fotos");
    return dir;
}

// ----- Imóveis -----

QList<ImovelInfo> Sistema::imoveis() const
{
    QList<ImovelInfo> lista;
    for (const Imovel &i : d->ger.get_imoveis()) {
        const Extras e = d->extras.value(i.get_id());
        lista.append({i.get_id(), QString::fromStdString(i.get_titulo()), i.get_preco_diaria(),
                      e.endereco, e.descricao, e.foto, e.capacidade});
    }
    return lista;
}

ImovelInfo Sistema::imovel(int id) const
{
    for (const ImovelInfo &i : imoveis())
        if (i.id == id)
            return i;
    return {};
}

int Sistema::salvarImovel(const ImovelInfo &info)
{
    int id = info.id;
    if (id == 0) {
        // Escolhe um id que ainda não existe (o GerenciadorCanais recusa ids repetidos)
        int maior = 0;
        for (const Imovel &i : d->ger.get_imoveis())
            maior = std::max(maior, i.get_id());
        id = std::max(d->proximoId, maior + 1);
        d->proximoId = id + 1;
        d->ger.adicionarImovel(Imovel(id, info.titulo.toStdString(), info.diaria));
    } else {
        Imovel *atual = d->ger.buscarImovel(id);
        if (!atual)
            return 0;
        // A classe Imovel não tem "editar": criamos um novo com os mesmos dados e reservas.
        Imovel novo(id, info.titulo.toStdString(), info.diaria);
        for (const Reserva &r : atual->get_reservas())
            novo.adicionarReserva(r);
        *atual = novo;
    }
    d->extras[id] = {info.endereco, info.descricao, info.foto, info.capacidade};
    salvarArquivo();
    emit dadosAlterados();
    return id;
}

void Sistema::excluirImovel(int id)
{
    // O GerenciadorCanais não tem "remover": recriamos com os imóveis restantes.
    GerenciadorCanais novo;
    DadosSistema::configurar(novo);
    for (const Imovel &i : d->ger.get_imoveis())
        if (i.get_id() != id)
            novo.adicionarImovel(i);
    d->ger = std::move(novo);
    d->extras.remove(id);
    salvarArquivo();
    emit dadosAlterados();
}

// ----- Hóspedes -----

QList<HospedeInfo> Sistema::hospedes() const
{
    QList<HospedeInfo> lista;
    for (const Hospede &h : d->hospedes)
        lista.append(deHospede(h));
    return lista;
}

HospedeInfo Sistema::hospede(const QString &documento) const
{
    for (const Hospede &h : d->hospedes)
        if (QString::fromStdString(h.get_documento()) == documento)
            return deHospede(h);
    return {};
}

bool Sistema::salvarHospede(const QString &documentoAnterior, const HospedeInfo &h, QString *erro)
{
    if (h.nome.trimmed().isEmpty() || h.documento.trimmed().isEmpty()) {
        if (erro) *erro = QObject::tr("Nome e documento são obrigatórios.");
        return false;
    }
    int posicao = -1;
    for (size_t i = 0; i < d->hospedes.size(); ++i) {
        const QString doc = QString::fromStdString(d->hospedes[i].get_documento());
        if (doc == documentoAnterior)
            posicao = static_cast<int>(i);
        else if (doc == h.documento) {
            if (erro) *erro = QObject::tr("Já existe um cliente com este documento.");
            return false;
        }
    }
    if (posicao >= 0)
        d->hospedes[posicao] = paraHospede(h); // Hospede não tem "set": substituímos o objeto
    else
        d->hospedes.push_back(paraHospede(h));
    salvarArquivo();
    emit dadosAlterados();
    return true;
}

bool Sistema::hospedeTemReservas(const QString &documento) const
{
    for (const Imovel &i : d->ger.get_imoveis())
        for (const Reserva &r : i.get_reservas())
            if (QString::fromStdString(r.get_hospede().get_documento()) == documento)
                return true;
    return false;
}

void Sistema::excluirHospede(const QString &documento)
{
    for (size_t i = 0; i < d->hospedes.size(); ++i) {
        if (QString::fromStdString(d->hospedes[i].get_documento()) == documento) {
            d->hospedes.erase(d->hospedes.begin() + static_cast<long>(i));
            break;
        }
    }
    salvarArquivo();
    emit dadosAlterados();
}

// ----- Reservas -----

QStringList Sistema::plataformas() const
{
    return d->nomesPlataformas;
}

QList<ReservaInfo> Sistema::reservasDoImovel(int imovelId) const
{
    QList<ReservaInfo> lista;
    for (const Imovel &i : d->ger.get_imoveis()) {
        if (i.get_id() != imovelId)
            continue;
        int idx = 0;
        for (const Reserva &r : i.get_reservas())
            lista.append(d->montar(imovelId, idx++, r));
    }
    return lista;
}

QList<ReservaInfo> Sistema::todasReservas() const
{
    QList<ReservaInfo> lista;
    for (const Imovel &i : d->ger.get_imoveis()) {
        int idx = 0;
        for (const Reserva &r : i.get_reservas())
            lista.append(d->montar(i.get_id(), idx++, r));
    }
    return lista;
}

double Sistema::calcularBruto(int imovelId, const QDate &in, const QDate &out) const
{
    const int noites = static_cast<int>(in.daysTo(out));
    return noites > 0 ? noites * imovel(imovelId).diaria : 0.0;
}

double Sistema::calcularLiquido(const QString &plataforma, double bruto) const
{
    return d->liquido(plataforma, bruto);
}

bool Sistema::registrarReserva(int imovelId, const HospedeInfo &h, const QDate &in,
                               const QDate &out, const QString &plataforma, QString *erro,
                               QStringList *avisosSincronizacao)
{
    if (!in.isValid() || !out.isValid() || out <= in) {
        if (erro) *erro = tr("O check-out deve ser depois do check-in.");
        return false;
    }
    try {
        const float bruto = static_cast<float>(calcularBruto(imovelId, in, out));
        const Reserva nova(paraData(in), paraData(out), paraHospede(h), bruto, plataforma.toStdString());
        const Plataforma *origem = d->ger.buscarPlataforma(plataforma.toStdString());

        // [Passo 8] O gerenciador valida, salva e simula o bloqueio nas outras plataformas.
        // Ele imprimiria os avisos no console; aqui devolvemos a lista para mostrar na tela.
        std::ostringstream console;
        const std::vector<std::string> avisos = d->ger.registrarReserva(imovelId, nova, origem, console);
        if (avisosSincronizacao)
            for (const std::string &a : avisos)
                avisosSincronizacao->append(QString::fromStdString(a));
    } catch (const std::runtime_error &) { // conflito de datas (overbooking)
        if (erro)
            *erro = tr("Já existe uma reserva neste imóvel que entra em conflito com este período "
                       "(overbooking).");
        return false;
    } catch (const std::exception &e) { // dados inválidos (imóvel inexistente, data inválida...)
        if (erro) *erro = QString::fromStdString(e.what());
        return false;
    }
    salvarArquivo();
    emit dadosAlterados();
    return true;
}

void Sistema::excluirReserva(int imovelId, int indice)
{
    Imovel *im = d->ger.buscarImovel(imovelId);
    if (!im)
        return;
    // A classe Imovel não tem "remover reserva": recriamos o imóvel sem ela.
    Imovel novo(im->get_id(), im->get_titulo(), im->get_preco_diaria());
    int idx = 0;
    for (const Reserva &r : im->get_reservas())
        if (idx++ != indice)
            novo.adicionarReserva(r);
    *im = novo;
    salvarArquivo();
    emit dadosAlterados();
}

QStringList Sistema::exportarReservas() const
{
    QStringList linhas;
    for (const Imovel &i : d->ger.get_imoveis()) {
        for (const Reserva &r : i.get_reservas()) {
            const Plataforma *p = d->ger.buscarPlataforma(r.get_nome_plataforma());
            const QString detalhe =
                p ? QString::fromStdString(p->formatarExportacao(r)) : QString();
            linhas << QString("%1 | %2 a %3 | %4")
                          .arg(QString::fromStdString(i.get_titulo()),
                               dataBR(paraQDate(r.get_check_in())),
                               dataBR(paraQDate(r.get_check_out())), detalhe);
        }
    }
    return linhas;
}

// ----- Importação, planilha e relatórios (usam os passos 9 e 11 do plano) -----

ResultadoImportacaoInfo Sistema::importarReservas(const QString &caminho)
{
    ResultadoImportacaoInfo info;
    QFile f(caminho);
    if (!f.open(QIODevice::ReadOnly)) {
        info.erro = tr("Não foi possível abrir o arquivo.");
        return info;
    }
    const QByteArray bytes = f.readAll();
    std::istringstream entrada(std::string(bytes.constData(), static_cast<size_t>(bytes.size())));
    std::ostringstream console; // os avisos de sincronização iriam para o console
    try {
        const ResultadoImportacao res = d->ger.importarReservas(entrada, "Airbnb", console);
        for (const std::string &x : res.aceitas) info.aceitas << QString::fromStdString(x);
        for (const std::string &x : res.conflitos) info.conflitos << QString::fromStdString(x);
        for (const std::string &x : res.invalidas) info.invalidas << QString::fromStdString(x);
        if (!res.reservasAceitas.empty()) {
            garantirHospedesDasReservas(); // hóspedes novos do arquivo entram na lista de clientes
            salvarArquivo();
            emit dadosAlterados();
        }
    } catch (const std::exception &e) {
        info.erro = QString::fromStdString(e.what());
    }
    return info;
}

bool Sistema::exportarPlanilha(const QString &caminho, QString *erro) const
{
    std::ostringstream saida;
    d->ger.exportarPlanilha(saida);
    if (!escreverArquivo(caminho, saida.str())) {
        if (erro) *erro = tr("Não foi possível salvar o arquivo.");
        return false;
    }
    return true;
}

QList<LinhaRelatorio> Sistema::relatorioPorImovel() const
{
    QList<LinhaRelatorio> lista;
    for (const Imovel &i : d->ger.get_imoveis()) {
        const Faturamento f = d->ger.faturamentoPorImovel(i.get_id());
        lista.append({QString::fromStdString(i.get_titulo()), f.reservas, f.bruto, f.liquido});
    }
    return lista;
}

QList<LinhaRelatorio> Sistema::relatorioPorPlataforma() const
{
    QList<LinhaRelatorio> lista;
    for (const QString &nome : d->nomesPlataformas) {
        const Faturamento f = d->ger.faturamentoPorPlataforma(nome.toStdString());
        lista.append({nome, f.reservas, f.bruto, f.liquido});
    }
    return lista;
}

LinhaRelatorio Sistema::relatorioTotal() const
{
    const Faturamento f = d->ger.faturamentoTotal();
    return {tr("Total geral"), f.reservas, f.bruto, f.liquido};
}

// ----- Arquivos -----
// imoveis.csv e reservas.csv: gravados pelas classes da equipe (passo 10).
// dados.json: o que as classes ainda não guardam (endereço, foto, capacidade, lista de clientes).

void Sistema::garantirHospedesDasReservas()
{
    for (const Imovel &i : d->ger.get_imoveis()) {
        for (const Reserva &r : i.get_reservas()) {
            const Hospede h = r.get_hospede();
            if (h.get_documento().empty())
                continue;
            bool achou = false;
            for (const Hospede &x : d->hospedes)
                if (x.get_documento() == h.get_documento()) { achou = true; break; }
            if (!achou)
                d->hospedes.push_back(h);
        }
    }
}

void Sistema::salvarArquivo() const
{
    const QString pasta = pastaDeDados();

    std::ostringstream imoveisCsv, reservasCsv;
    d->ger.salvarImoveisCsv(imoveisCsv);
    d->ger.salvarReservasCsv(reservasCsv);
    escreverArquivo(pasta + "/imoveis.csv", imoveisCsv.str());
    escreverArquivo(pasta + "/reservas.csv", reservasCsv.str());

    QJsonObject extrasJson;
    for (auto it = d->extras.cbegin(); it != d->extras.cend(); ++it)
        extrasJson[QString::number(it.key())] = QJsonObject{{"endereco", it.value().endereco},
                                                            {"descricao", it.value().descricao},
                                                            {"foto", it.value().foto},
                                                            {"capacidade", it.value().capacidade}};
    QJsonArray hospedesJson;
    for (const Hospede &h : d->hospedes) {
        const HospedeInfo i = deHospede(h);
        hospedesJson.append(QJsonObject{{"nome", i.nome}, {"documento", i.documento},
                                        {"telefone", i.telefone}, {"email", i.email}});
    }
    const QJsonObject raiz{{"proximoId", d->proximoId}, {"extras", extrasJson},
                           {"hospedes", hospedesJson}};
    escreverArquivo(pasta + "/dados.json",
                    QJsonDocument(raiz).toJson(QJsonDocument::Indented).toStdString());
}

void Sistema::carregarArquivo()
{
    const QString pasta = pastaDeDados();

    // Imóveis e reservas (classes da equipe). Linhas com problema são ignoradas e avisadas.
    {
        std::istringstream im(lerArquivo(pasta + "/imoveis.csv"));
        for (const std::string &aviso : d->ger.carregarImoveisCsv(im))
            qWarning("%s", aviso.c_str());
        std::istringstream rs(lerArquivo(pasta + "/reservas.csv"));
        for (const std::string &aviso : d->ger.carregarReservasCsv(rs))
            qWarning("%s", aviso.c_str());
    }

    // Dados extras e lista de clientes
    QFile f(pasta + "/dados.json");
    if (f.open(QIODevice::ReadOnly)) {
        const QJsonObject raiz = QJsonDocument::fromJson(f.readAll()).object();
        d->proximoId = raiz["proximoId"].toInt(1);
        for (const auto &v : raiz["hospedes"].toArray()) {
            const QJsonObject o = v.toObject();
            d->hospedes.push_back(paraHospede({o["nome"].toString(), o["documento"].toString(),
                                               o["telefone"].toString(), o["email"].toString()}));
        }
        const QJsonObject extrasJson = raiz["extras"].toObject();
        for (auto it = extrasJson.begin(); it != extrasJson.end(); ++it) {
            const QJsonObject o = it.value().toObject();
            d->extras[it.key().toInt()] = {o["endereco"].toString(), o["descricao"].toString(),
                                           o["foto"].toString(), o["capacidade"].toInt(1)};
        }
    }
    garantirHospedesDasReservas();
}
