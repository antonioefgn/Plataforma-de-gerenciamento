#include "paginapainel.h"
#include "ui_paginapainel.h"

#include <algorithm>

#include "sistema.h"

PaginaPainel::PaginaPainel(QWidget *parent) : QWidget(parent), ui(new Ui::PaginaPainel)
{
    ui->setupUi(this);
    connect(&Sistema::instancia(), &Sistema::dadosAlterados, this, [this] { atualizar(); });
    atualizar();
}

PaginaPainel::~PaginaPainel()
{
    delete ui;
}

void PaginaPainel::atualizar()
{
    auto &sistema = Sistema::instancia();
    const QDate hoje = QDate::currentDate();
    const QDate inicioMes(hoje.year(), hoje.month(), 1);
    const QList<ImovelInfo> imoveis = sistema.imoveis();
    QList<ReservaInfo> reservas = sistema.todasReservas();

    int ativas = 0;
    double brutoMes = 0, liquidoMes = 0;
    for (const ReservaInfo &r : reservas) {
        if (r.checkOut >= hoje)
            ++ativas;
        if (r.checkIn.year() == hoje.year() && r.checkIn.month() == hoje.month()) {
            brutoMes += r.bruto;
            liquidoMes += r.liquido;
        }
    }

    // Ocupação do mês = noites ocupadas / (imóveis × dias do mês)
    int noitesOcupadas = 0;
    for (const ImovelInfo &im : imoveis) {
        for (int dia = 0; dia < hoje.daysInMonth(); ++dia) {
            const QDate d = inicioMes.addDays(dia);
            for (const ReservaInfo &r : reservas) {
                if (r.imovelId == im.id && d >= r.checkIn && d < r.checkOut) {
                    ++noitesOcupadas;
                    break;
                }
            }
        }
    }
    const int totalNoites = imoveis.size() * hoje.daysInMonth();
    const double ocupacao = totalNoites > 0 ? 100.0 * noitesOcupadas / totalNoites : 0.0;

    ui->cardValor0->setText(QString::number(imoveis.size()));
    ui->cardValor1->setText(QString::number(sistema.hospedes().size()));
    ui->cardValor2->setText(QString::number(ativas));
    ui->cardValor3->setText(moeda(brutoMes));
    ui->cardValor4->setText(QString::number(ocupacao, 'f', 0) + "%");
    ui->cardValor5->setText(moeda(liquidoMes));

    auto descricao = [&](const ReservaInfo &r) {
        return QString("%1 — %2").arg(r.hospede.nome, sistema.imovel(r.imovelId).titulo);
    };

    ui->listaCheckIn->clear();
    ui->listaCheckOut->clear();
    std::sort(reservas.begin(), reservas.end(),
              [](const ReservaInfo &a, const ReservaInfo &b) { return a.checkIn < b.checkIn; });
    for (const ReservaInfo &r : std::as_const(reservas))
        if (r.checkIn >= hoje && ui->listaCheckIn->count() < 8)
            ui->listaCheckIn->addItem(dataBR(r.checkIn) + "  " + descricao(r));
    std::sort(reservas.begin(), reservas.end(),
              [](const ReservaInfo &a, const ReservaInfo &b) { return a.checkOut < b.checkOut; });
    for (const ReservaInfo &r : std::as_const(reservas))
        if (r.checkOut >= hoje && ui->listaCheckOut->count() < 8)
            ui->listaCheckOut->addItem(dataBR(r.checkOut) + "  " + descricao(r));

    if (ui->listaCheckIn->count() == 0)
        ui->listaCheckIn->addItem(tr("Nenhum check-in agendado."));
    if (ui->listaCheckOut->count() == 0)
        ui->listaCheckOut->addItem(tr("Nenhum check-out agendado."));
}
