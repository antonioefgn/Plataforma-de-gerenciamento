#pragma once

#include <QCalendarWidget>
#include <QFont>
#include <QList>
#include <QPainter>

#include "sistema.h"

// Calendário que pinta:
//   verde    = check-in
//   laranja  = check-out
//   vermelho = dias ocupados entre os dois
//   azul     = período que está sendo escolhido para um novo aluguel
// Aparece no Designer como "widget promovido" (extends QCalendarWidget).
class CalendarioReservas : public QCalendarWidget {
public:
    explicit CalendarioReservas(QWidget *parent = nullptr) : QCalendarWidget(parent)
    {
        setLocale(QLocale(QLocale::Portuguese, QLocale::Brazil));
    }

    void setReservas(const QList<ReservaInfo> &reservas)
    {
        m_reservas = reservas;
        updateCells();
    }

    void setSelecao(const QDate &entrada, const QDate &saida)
    {
        m_selEntrada = entrada;
        m_selSaida = saida;
        updateCells();
    }

protected:
    void paintCell(QPainter *p, const QRect &rect, QDate d) const override
    {
        QCalendarWidget::paintCell(p, rect, d);

        bool entrada = false, saida = false, meio = false;
        for (const auto &r : m_reservas) {
            if (d == r.checkIn) entrada = true;
            else if (d == r.checkOut) saida = true;
            else if (d > r.checkIn && d < r.checkOut) meio = true;
        }

        const QRect rc = rect.adjusted(1, 1, -1, -1);
        const QColor verde(67, 160, 71, 200), laranja(251, 140, 0, 200),
            vermelho(229, 57, 53, 140), azul(30, 136, 229, 90);

        p->save();
        if (meio)
            p->fillRect(rc, vermelho);
        if (entrada && saida) { // um hóspede sai e outro entra no mesmo dia
            p->fillRect(QRect(rc.left(), rc.top(), rc.width() / 2, rc.height()), laranja);
            p->fillRect(QRect(rc.center().x(), rc.top(), rc.width() - rc.width() / 2, rc.height()), verde);
        } else if (entrada) {
            p->fillRect(rc, verde);
        } else if (saida) {
            p->fillRect(rc, laranja);
        }

        QFont f = p->font();
        f.setPointSizeF(qMax(6.0, f.pointSizeF() * 0.7));
        f.setBold(true);
        p->setFont(f);
        p->setPen(Qt::white);
        if (entrada && saida)
            p->drawText(rc.adjusted(0, 0, 0, -2), Qt::AlignHCenter | Qt::AlignBottom, "OUT/IN");
        else if (entrada)
            p->drawText(rc.adjusted(0, 0, 0, -2), Qt::AlignHCenter | Qt::AlignBottom, "IN");
        else if (saida)
            p->drawText(rc.adjusted(0, 0, 0, -2), Qt::AlignHCenter | Qt::AlignBottom, "OUT");

        if (m_selEntrada.isValid()) {
            const QDate fim = m_selSaida.isValid() ? m_selSaida : m_selEntrada;
            if (d >= m_selEntrada && d <= fim) {
                p->fillRect(rc, azul);
                if (d == m_selEntrada || d == fim) {
                    p->setPen(QPen(QColor(21, 101, 192), 2));
                    p->drawRect(rc.adjusted(1, 1, -1, -1));
                }
            }
        }
        p->restore();
    }

private:
    QList<ReservaInfo> m_reservas;
    QDate m_selEntrada, m_selSaida;
};
