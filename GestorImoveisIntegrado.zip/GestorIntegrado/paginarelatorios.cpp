#include "paginarelatorios.h"
#include "ui_paginarelatorios.h"

#include <QHeaderView>

#include "sistema.h"

namespace {

void preencher(QTableWidget *tabela, const QList<LinhaRelatorio> &linhas)
{
    tabela->setRowCount(linhas.size());
    for (int r = 0; r < linhas.size(); ++r) {
        const LinhaRelatorio &l = linhas[r];
        auto *reservas = new QTableWidgetItem(QString::number(l.reservas));
        reservas->setTextAlignment(Qt::AlignCenter);
        auto *bruto = new QTableWidgetItem(moeda(l.bruto));
        bruto->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        auto *liquido = new QTableWidgetItem(moeda(l.liquido));
        liquido->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        tabela->setItem(r, 0, new QTableWidgetItem(l.nome));
        tabela->setItem(r, 1, reservas);
        tabela->setItem(r, 2, bruto);
        tabela->setItem(r, 3, liquido);
    }
}

} // namespace

PaginaRelatorios::PaginaRelatorios(QWidget *parent) : QWidget(parent), ui(new Ui::PaginaRelatorios)
{
    ui->setupUi(this);
    for (QTableWidget *t : {ui->tabelaPorImovel, ui->tabelaPorPlataforma}) {
        t->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
        t->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);
    }
    connect(&Sistema::instancia(), &Sistema::dadosAlterados, this, [this] { atualizar(); });
    atualizar();
}

PaginaRelatorios::~PaginaRelatorios()
{
    delete ui;
}

void PaginaRelatorios::resizeEvent(QResizeEvent *e)
{
    QWidget::resizeEvent(e);
    ui->splitter->setOrientation(width() < 860 ? Qt::Vertical : Qt::Horizontal);
}

void PaginaRelatorios::atualizar()
{
    auto &sistema = Sistema::instancia();
    preencher(ui->tabelaPorImovel, sistema.relatorioPorImovel());
    preencher(ui->tabelaPorPlataforma, sistema.relatorioPorPlataforma());
    const LinhaRelatorio t = sistema.relatorioTotal();
    ui->totalGeral->setText(tr("Total geral: %1 reserva(s)  |  bruto %2  |  líquido %3")
                                .arg(t.reservas)
                                .arg(moeda(t.bruto), moeda(t.liquido)));
}
