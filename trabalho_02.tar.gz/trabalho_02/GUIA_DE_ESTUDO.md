# Guia de estudo do projeto

Este guia acompanha os comentários colocados nos fontes e mostra o caminho de uma ação feita na interface até a regra de negócio.

## 1. Separação das responsabilidades

`src/domain/` não inclui nenhum cabeçalho do Qt. Isso é intencional: regras como validação de data, comissão e conflito de reservas podem ser testadas com `g++`, sem abrir uma janela. `src/gui/` contém apenas widgets, conversões de `QDate` e mensagens ao usuário.

Quando o usuário clica em **Registrar reserva**, o método `MainWindow::registrarReserva()` apenas lê os campos e chama `GerenciadorCanais::registrarReserva()`. É o gerenciador que verifica hóspede, imóvel, canal, preço, capacidade e conflito. Assim, uma futura tela web ou CLI poderia reutilizar exatamente a mesma regra.

## 2. Regra de conflito

Em `reserva.h` está a expressão:

```cpp
return checkIn_ < outra.checkOut_ && checkOut_ > outra.checkIn_;
```

Ela representa intervalos semiabertos: `[check-in, check-out)`. Portanto, uma estadia de 10 a 15 ocupa as noites 10, 11, 12, 13 e 14; outra começando no dia 15 é válida. O teste em `tests/test_domain.cpp` comprova os dois casos.

## 3. Polimorfismo das plataformas

`Plataforma` é abstrata e cada filho redefine `valorLiquido()`. No relatório, `GerenciadorCanais::valorLiquido()` recebe uma `Reserva`, localiza o canal e chama a função virtual. Esse é o ponto em que o código usa polimorfismo: não há `if (canal == "Airbnb")` espalhado pela aplicação.

## 4. Persistência simples

Após cada alteração, `persistir()` chama `GerenciadorCanais::salvar()`. Ele gera três CSVs independentes. Ao iniciar, `carregar()` recompõe os objetos e avança os próximos IDs para não repetir registros. Campos com `;` ou quebras de linha são higienizados antes da gravação, pois `;` é o separador adotado pelo arquivo.

## 5. Onde evoluir

- Trocar os CSVs por SQLite mantendo a mesma interface pública do gerenciador.
- Guardar apenas uma cópia da foto no diretório de dados em vez do caminho absoluto escolhido pelo usuário.
- Criar uma entidade `Usuario` e substituir o login demonstrativo por hash de senha.
- Aplicar regras mais completas a pagamentos, limpeza e ocupação que atravesse a virada do mês.
