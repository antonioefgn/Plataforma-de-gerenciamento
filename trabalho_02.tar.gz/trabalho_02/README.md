# Gestor de Aluguéis — Qt/C++

Aplicação desktop para administrar imóveis de temporada e reservas recebidas por Airbnb, Booking, contato direto, WhatsApp ou outro canal. O projeto foi refeito de forma independente do esqueleto recebido para manter a interface Qt separada da regra de negócio em C++.

## O que foi implementado

- Login demonstrativo: `admin` / `1234`.
- Cadastro, edição, foto e exclusão protegida de imóveis.
- Cadastro, busca, edição e exclusão protegida de hóspedes.
- Registro de reservas com cálculo automático por quantidade de noites e bloqueio de sobreposição.
- Check-out e novo check-in no mesmo dia são aceitos; só períodos que compartilham uma noite entram em conflito.
- Cancelamento e conclusão de reservas, calendário dos dias ocupados e painel financeiro.
- Comissão polimórfica: Airbnb (15%), Booking (12% + R$ 80) e Direto (0%).
- Persistência automática em três CSVs (`imoveis.csv`, `hospedes.csv`, `reservas.csv`) no diretório de dados do aplicativo.
- Importação do formato de texto proposto para o Airbnb e exportação de reservas em CSV.

## Organização para estudo

```
src/domain/  # Classes C++ puras: Data, Hospede, Reserva, Imovel, Plataforma e Gerenciador
src/gui/     # Widgets e ações da interface Qt
tests/       # Teste de regras essenciais, sem depender do Qt
dados/       # Exemplo de arquivo de importação
```

Os comentários no código explicam as decisões relevantes: polimorfismo em `plataforma.h`, regra de conflito em `reserva.h` e persistência/importação em `gerenciador.cpp`.

## Como compilar

Pré-requisitos: Qt 6 com o módulo **Widgets**, CMake 3.21+ e compilador C++17.

```bash
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

Execute `build/GestorAlugueis` (Linux/macOS) ou `build\GestorAlugueis.exe` (Windows). No Qt Creator, basta abrir `CMakeLists.txt`, selecionar um kit Qt 6 e executar.

## Como testar a importação

1. Cadastre um imóvel; o primeiro recebe ID `1`.
2. Use **Importar Airbnb** na barra superior e selecione `dados/novas_reservas_airbnb.txt`.
3. A primeira e a terceira linhas serão aceitas; a segunda será rejeitada por sobrepor a primeira. Linhas iniciadas por `#` são comentários e são ignoradas.
