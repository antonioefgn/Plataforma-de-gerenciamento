#include "domain/gerenciador.h"

#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>

int main() {
    // Datas encostadas não conflitam: uma reserva pode sair no dia em que outra entra.
    Reserva primeira(1, "111", Data(10, 12, 2026), Data(15, 12, 2026), 1, "Direto", "Pago", "", 500);
    Reserva segunda(2, "222", Data(15, 12, 2026), Data(18, 12, 2026), 1, "Airbnb", "Pendente", "", 300);
    Reserva sobreposta(3, "333", Data(14, 12, 2026), Data(17, 12, 2026), 1, "Airbnb", "Pendente", "", 300);
    assert(!primeira.conflitaCom(segunda));
    assert(primeira.conflitaCom(sobreposta));

    GerenciadorCanais gestor;
    const int imovel = gestor.criarImovel("Casa de teste", "Rua A", 200, 4, "", "");
    gestor.salvarHospede(Hospede("Ana", "111", "", ""));
    gestor.registrarReserva(imovel, "111", Data(1, 1, 2027), Data(4, 1, 2027), 2, "Airbnb", "Pago", "");
    assert(gestor.buscarImovel(imovel)->reservas().front().valorBruto() == 600.0);
    assert(gestor.valorLiquido(gestor.buscarImovel(imovel)->reservas().front()) == 510.0);

    // Persistência recompõe os objetos e preserva IDs para a próxima execução.
    const std::string pasta = "/tmp/gestor_alugueis_teste";
    std::filesystem::remove_all(pasta);
    gestor.salvar(pasta);
    GerenciadorCanais recarregado;
    recarregado.carregar(pasta);
    assert(recarregado.imoveis().size() == 1);
    assert(recarregado.buscarImovel(imovel)->reservas().size() == 1);

    // Importação aceita uma linha válida e informa uma segunda sobreposta.
    const std::string arquivoImportacao = pasta + "/airbnb.txt";
    std::ofstream entrada(arquivoImportacao);
    entrada << "1;10;12;2026;15;12;2026;Carlos;222;83999999999;c@x.com;1500.00\n";
    entrada << "1;12;12;2026;18;12;2026;Ana;333;83988888888;a@x.com;1800.00\n";
    entrada.close();
    const ResultadoImportacao resultado = recarregado.importarAirbnb(arquivoImportacao);
    assert(resultado.aceitas == 1 && resultado.rejeitadas.size() == 1);
    std::filesystem::remove_all(pasta);
    std::cout << "Testes de dominio aprovados.\n";
}
