#include "gui/logindialog.h"
#include "gui/mainwindow.h"

#include <QApplication>

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);
    app.setStyleSheet(R"(
        QWidget { font-family: "Segoe UI", Arial; font-size: 10pt; color: #1f2937; }
        QMainWindow, QDialog { background: #f4f7fb; }
        QLabel#titulo, QLabel#tituloPagina { font-size: 22pt; font-weight: 700; color: #173b65; }
        QTabBar::tab { padding: 10px 18px; } QTabBar::tab:selected { color: #1d4ed8; font-weight: bold; }
        QFrame#cartao { background: white; border: 1px solid #dbe3ed; border-radius: 10px; min-height: 78px; }
        QLabel#cartaoTitulo { color: #64748b; } QLabel#cartaoValor { font-size: 18pt; font-weight: bold; color: #173b65; }
        QLabel#foto { background: #eef2f7; border: 2px dashed #b8c4d2; border-radius: 8px; color: #64748b; }
        QGroupBox { font-weight: bold; border: 1px solid #dbe3ed; border-radius: 8px; margin-top: 10px; padding: 10px; }
        QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
        QLineEdit, QComboBox, QDateEdit, QSpinBox, QDoubleSpinBox, QPlainTextEdit { background: white; border: 1px solid #cbd5e1; border-radius: 5px; padding: 5px; }
        QPushButton { background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 5px; padding: 7px 12px; }
        QPushButton:hover { background: #e8eef7; } QPushButton[primario="true"] { background: #2563eb; color: white; border: none; font-weight: bold; }
        QPushButton[primario="true"]:hover { background: #1d4ed8; }
        QTableWidget { background: white; border: 1px solid #dbe3ed; border-radius: 5px; } QHeaderView::section { background: #eaf0f7; padding: 6px; border: 0; font-weight: bold; }
    )");
    LoginDialog login;
    if (login.exec() != QDialog::Accepted) return 0;
    MainWindow janela; janela.show();
    return app.exec();
}
