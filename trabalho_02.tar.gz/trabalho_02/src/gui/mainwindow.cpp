#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QCalendarWidget>
#include <QCloseEvent>
#include <QColor>
#include <QDate>
#include <QFileDialog>
#include <QHeaderView>
#include <QMessageBox>
#include <QLocale>
#include <QPixmap>
#include <QSignalBlocker>
#include <QStandardPaths>
#include <QTableWidget>
#include <QTextCharFormat>

namespace {
Data paraData(const QDate& d) { return Data(d.day(), d.month(), d.year()); }
QDate paraQDate(const Data& d) { return QDate(d.ano(), d.mes(), d.dia()); }
QTableWidgetItem* item(const QString& texto, int id = -1) {
    auto* resultado = new QTableWidgetItem(texto);
    if (id >= 0) resultado->setData(Qt::UserRole, id);
    return resultado;
}
}

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    diretorioDados_ = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation) + "/dados";
    ui->barraFerramentas->addAction(ui->acaoImportarAirbnb);
    ui->barraFerramentas->addAction(ui->acaoExportar);
    ui->tabelaImoveis->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tabelaHospedes->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tabelaReservas->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tabelaImoveis->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tabelaHospedes->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tabelaReservas->setSelectionBehavior(QAbstractItemView::SelectRows);
    try { gestor_.carregar(diretorioDados_.toStdString()); } catch (const std::exception& e) { avisoErro(e); }
    conectarEventos(); atualizarTudo();
}
MainWindow::~MainWindow() { delete ui; }

void MainWindow::conectarEventos() {
    connect(ui->btnNovoImovel, &QPushButton::clicked, this, [this] { novoImovel(); });
    connect(ui->btnSalvarImovel, &QPushButton::clicked, this, [this] { salvarImovel(); });
    connect(ui->btnExcluirImovel, &QPushButton::clicked, this, [this] { excluirImovel(); });
    connect(ui->btnEscolherFoto, &QPushButton::clicked, this, [this] { escolherFoto(); });
    connect(ui->tabelaImoveis, &QTableWidget::itemSelectionChanged, this, [this] { selecionarImovel(); });
    connect(ui->btnNovoHospede, &QPushButton::clicked, this, [this] { novoHospede(); });
    connect(ui->btnSalvarHospede, &QPushButton::clicked, this, [this] { salvarHospede(); });
    connect(ui->btnExcluirHospede, &QPushButton::clicked, this, [this] { excluirHospede(); });
    connect(ui->buscaHospede, &QLineEdit::textChanged, this, [this] { atualizarTabelaHospedes(); });
    connect(ui->tabelaHospedes, &QTableWidget::itemSelectionChanged, this, [this] { selecionarHospede(); });
    connect(ui->imovelReserva, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int) { atualizarReservas(); });
    connect(ui->entradaReserva, &QDateEdit::dateChanged, this, [this](const QDate&) { atualizarReservas(); });
    connect(ui->saidaReserva, &QDateEdit::dateChanged, this, [this](const QDate&) { atualizarReservas(); });
    connect(ui->btnRegistrarReserva, &QPushButton::clicked, this, [this] { registrarReserva(); });
    connect(ui->btnConcluir, &QPushButton::clicked, this, [this] { mudarStatusSelecionada(StatusReserva::Concluida); });
    connect(ui->btnCancelar, &QPushButton::clicked, this, [this] { mudarStatusSelecionada(StatusReserva::Cancelada); });
    connect(ui->btnExportar, &QPushButton::clicked, this, [this] { exportar(); });
    connect(ui->acaoExportar, &QAction::triggered, this, [this] { exportar(); });
    connect(ui->acaoImportarAirbnb, &QAction::triggered, this, [this] { importarAirbnb(); });
}

QString MainWindow::dinheiro(double valor) const { return QLocale(QLocale::Portuguese, QLocale::Brazil).toCurrencyString(valor, "R$ "); }
int MainWindow::idImovelSelecionado() const { const int l = ui->tabelaImoveis->currentRow(); return l < 0 ? -1 : ui->tabelaImoveis->item(l, 0)->data(Qt::UserRole).toInt(); }
int MainWindow::idReservaSelecionada() const { const int l = ui->tabelaReservas->currentRow(); return l < 0 ? -1 : ui->tabelaReservas->item(l, 0)->data(Qt::UserRole).toInt(); }
void MainWindow::avisoErro(const std::exception& erro) { QMessageBox::warning(this, "Operacao nao realizada", erro.what()); }
void MainWindow::persistir() { try { gestor_.salvar(diretorioDados_.toStdString()); } catch (const std::exception& e) { avisoErro(e); } }
void MainWindow::closeEvent(QCloseEvent* event) { persistir(); event->accept(); }

void MainWindow::atualizarTudo() { atualizarTabelaImoveis(); atualizarTabelaHospedes(); atualizarCombos(); atualizarReservas(); atualizarPainel(); }
void MainWindow::atualizarTabelaImoveis() {
    QSignalBlocker bloqueio(ui->tabelaImoveis); ui->tabelaImoveis->setRowCount(0);
    for (const auto& i : gestor_.imoveis()) { const int l = ui->tabelaImoveis->rowCount(); ui->tabelaImoveis->insertRow(l); ui->tabelaImoveis->setItem(l, 0, item(QString::number(i.id()), i.id())); ui->tabelaImoveis->setItem(l, 1, item(QString::fromStdString(i.nome()))); ui->tabelaImoveis->setItem(l, 2, item(dinheiro(i.diaria()))); ui->tabelaImoveis->setItem(l, 3, item(QString::number(i.capacidade()))); }
}
void MainWindow::atualizarTabelaHospedes() {
    QSignalBlocker bloqueio(ui->tabelaHospedes); ui->tabelaHospedes->setRowCount(0); const QString busca = ui->buscaHospede->text();
    for (const auto& h : gestor_.hospedes()) { const QString nome = QString::fromStdString(h.nome()), doc = QString::fromStdString(h.documento()); if (!busca.isEmpty() && !nome.contains(busca, Qt::CaseInsensitive) && !doc.contains(busca, Qt::CaseInsensitive)) continue; const int l = ui->tabelaHospedes->rowCount(); ui->tabelaHospedes->insertRow(l); ui->tabelaHospedes->setItem(l, 0, item(nome)); ui->tabelaHospedes->setItem(l, 1, item(doc)); ui->tabelaHospedes->setItem(l, 2, item(QString::fromStdString(h.telefone()))); ui->tabelaHospedes->setItem(l, 3, item(QString::fromStdString(h.email()))); }
}
void MainWindow::atualizarCombos() {
    const int idAtual = ui->imovelReserva->currentData().toInt(); QSignalBlocker b1(ui->imovelReserva); ui->imovelReserva->clear(); for (const auto& i : gestor_.imoveis()) ui->imovelReserva->addItem(QString::fromStdString(i.nome()), i.id()); int indice = ui->imovelReserva->findData(idAtual); if (indice >= 0) ui->imovelReserva->setCurrentIndex(indice);
    const QString docAtual = ui->hospedeReserva->currentData().toString(); QSignalBlocker b2(ui->hospedeReserva); ui->hospedeReserva->clear(); for (const auto& h : gestor_.hospedes()) ui->hospedeReserva->addItem(QString::fromStdString(h.nome()), QString::fromStdString(h.documento())); indice = ui->hospedeReserva->findData(docAtual); if (indice >= 0) ui->hospedeReserva->setCurrentIndex(indice);
}
void MainWindow::atualizarReservas() {
    const int id = ui->imovelReserva->currentData().toInt();
    try { ui->totalReserva->setText(dinheiro(gestor_.preverTotal(id, paraData(ui->entradaReserva->date()), paraData(ui->saidaReserva->date())))); } catch (...) { ui->totalReserva->setText("R$ 0,00"); }
    QSignalBlocker bloqueio(ui->tabelaReservas); ui->tabelaReservas->setRowCount(0); const Imovel* imovel = gestor_.buscarImovel(id); if (!imovel) { atualizarCalendario(); return; }
    for (const auto& r : imovel->reservas()) { const Hospede* h = gestor_.buscarHospede(r.documentoHospede()); const int l = ui->tabelaReservas->rowCount(); ui->tabelaReservas->insertRow(l); ui->tabelaReservas->setItem(l, 0, item(QString::fromStdString(h ? h->nome() : r.documentoHospede()), r.id())); ui->tabelaReservas->setItem(l, 1, item(QString::fromStdString(r.checkIn().texto()))); ui->tabelaReservas->setItem(l, 2, item(QString::fromStdString(r.checkOut().texto()))); ui->tabelaReservas->setItem(l, 3, item(QString::fromStdString(r.canal()))); ui->tabelaReservas->setItem(l, 4, item(dinheiro(r.valorBruto()))); ui->tabelaReservas->setItem(l, 5, item(QString::fromStdString(textoStatus(r.status())))); }
    atualizarCalendario();
}
void MainWindow::atualizarCalendario() {
    ui->calendario->setDateTextFormat(QDate(), QTextCharFormat()); const Imovel* imovel = gestor_.buscarImovel(ui->imovelReserva->currentData().toInt()); if (!imovel) return; QTextCharFormat ocupado; ocupado.setBackground(QColor("#fecaca")); ocupado.setToolTip("Dia ocupado"); for (const auto& r : imovel->reservas()) if (r.status() != StatusReserva::Cancelada) for (QDate d = paraQDate(r.checkIn()); d < paraQDate(r.checkOut()); d = d.addDays(1)) ui->calendario->setDateTextFormat(d, ocupado);
}
void MainWindow::atualizarPainel() {
    const QDate hoje = QDate::currentDate(); const auto r = gestor_.resumo(hoje.month(), hoje.year()); ui->cardImoveis->setText(QString::number(r.imoveis)); ui->cardHospedes->setText(QString::number(r.hospedes)); ui->cardReservas->setText(QString::number(r.reservasAtivas)); ui->cardReceita->setText(dinheiro(r.receitaMes)); ui->cardOcupacao->setText(QString::number(r.ocupacaoMes, 'f', 1) + "%"); ui->cardReceber->setText(dinheiro(r.aReceber));
}

void MainWindow::novoImovel() { ui->tabelaImoveis->clearSelection(); ui->nomeImovel->clear(); ui->enderecoImovel->clear(); ui->diariaImovel->setValue(0); ui->capacidadeImovel->setValue(1); ui->descricaoImovel->clear(); caminhoFoto_.clear(); ui->fotoImovel->setPixmap(QPixmap()); ui->fotoImovel->setText("Sem foto"); }
void MainWindow::selecionarImovel() { const Imovel* i = gestor_.buscarImovel(idImovelSelecionado()); if (!i) return; ui->nomeImovel->setText(QString::fromStdString(i->nome())); ui->enderecoImovel->setText(QString::fromStdString(i->endereco())); ui->diariaImovel->setValue(i->diaria()); ui->capacidadeImovel->setValue(i->capacidade()); ui->descricaoImovel->setPlainText(QString::fromStdString(i->descricao())); caminhoFoto_ = QString::fromStdString(i->foto()); QPixmap p(caminhoFoto_); ui->fotoImovel->setPixmap(p.scaled(ui->fotoImovel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation)); ui->fotoImovel->setText(p.isNull() ? "Sem foto" : ""); const int indice = ui->imovelReserva->findData(i->id()); if (indice >= 0) ui->imovelReserva->setCurrentIndex(indice); }
void MainWindow::escolherFoto() { const QString arq = QFileDialog::getOpenFileName(this, "Foto", {}, "Imagens (*.png *.jpg *.jpeg)"); if (arq.isEmpty()) return; caminhoFoto_ = arq; QPixmap p(arq); ui->fotoImovel->setPixmap(p.scaled(ui->fotoImovel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation)); ui->fotoImovel->setText(""); }
void MainWindow::salvarImovel() { try { int id = idImovelSelecionado(); if (id < 0) id = gestor_.criarImovel(ui->nomeImovel->text().trimmed().toStdString(), ui->enderecoImovel->text().trimmed().toStdString(), ui->diariaImovel->value(), ui->capacidadeImovel->value(), ui->descricaoImovel->toPlainText().toStdString(), caminhoFoto_.toStdString()); else gestor_.atualizarImovel(id, ui->nomeImovel->text().trimmed().toStdString(), ui->enderecoImovel->text().trimmed().toStdString(), ui->diariaImovel->value(), ui->capacidadeImovel->value(), ui->descricaoImovel->toPlainText().toStdString(), caminhoFoto_.toStdString()); persistir(); atualizarTudo(); } catch (const std::exception& e) { avisoErro(e); } }
void MainWindow::excluirImovel() { try { const int id = idImovelSelecionado(); if (id < 0) throw std::runtime_error("Selecione um imovel"); gestor_.excluirImovel(id); persistir(); novoImovel(); atualizarTudo(); } catch (const std::exception& e) { avisoErro(e); } }
void MainWindow::novoHospede() { ui->tabelaHospedes->clearSelection(); ui->nomeHospede->clear(); ui->docHospede->clear(); ui->telHospede->clear(); ui->emailHospede->clear(); ui->docHospede->setReadOnly(false); }
void MainWindow::selecionarHospede() { const int l = ui->tabelaHospedes->currentRow(); if (l < 0) return; const Hospede* h = gestor_.buscarHospede(ui->tabelaHospedes->item(l, 1)->text().toStdString()); if (!h) return; ui->nomeHospede->setText(QString::fromStdString(h->nome())); ui->docHospede->setText(QString::fromStdString(h->documento())); ui->telHospede->setText(QString::fromStdString(h->telefone())); ui->emailHospede->setText(QString::fromStdString(h->email())); ui->docHospede->setReadOnly(true); }
void MainWindow::salvarHospede() { try { gestor_.salvarHospede(Hospede(ui->nomeHospede->text().trimmed().toStdString(), ui->docHospede->text().trimmed().toStdString(), ui->telHospede->text().trimmed().toStdString(), ui->emailHospede->text().trimmed().toStdString())); persistir(); atualizarTudo(); } catch (const std::exception& e) { avisoErro(e); } }
void MainWindow::excluirHospede() { try { const int l = ui->tabelaHospedes->currentRow(); if (l < 0) throw std::runtime_error("Selecione um hospede"); gestor_.excluirHospede(ui->tabelaHospedes->item(l, 1)->text().toStdString()); persistir(); novoHospede(); atualizarTudo(); } catch (const std::exception& e) { avisoErro(e); } }
void MainWindow::registrarReserva() { try { const int id = ui->imovelReserva->currentData().toInt(); if (id <= 0 || ui->hospedeReserva->currentData().toString().isEmpty()) throw std::runtime_error("Cadastre e selecione um imovel e um hospede"); gestor_.registrarReserva(id, ui->hospedeReserva->currentData().toString().toStdString(), paraData(ui->entradaReserva->date()), paraData(ui->saidaReserva->date()), ui->qtdHospedesReserva->value(), ui->canalReserva->currentText().toStdString(), ui->pagamentoReserva->currentText().toStdString(), ui->obsReserva->toPlainText().toStdString()); persistir(); ui->obsReserva->clear(); atualizarTudo(); } catch (const std::exception& e) { avisoErro(e); } }
void MainWindow::mudarStatusSelecionada(StatusReserva status) { try { const int id = idReservaSelecionada(); if (id < 0) throw std::runtime_error("Selecione uma reserva"); gestor_.mudarStatusReserva(ui->imovelReserva->currentData().toInt(), id, status); persistir(); atualizarTudo(); } catch (const std::exception& e) { avisoErro(e); } }
void MainWindow::exportar() { const QString arq = QFileDialog::getSaveFileName(this, "Exportar reservas", "reservas_exportadas.csv", "CSV (*.csv)"); if (arq.isEmpty()) return; try { gestor_.exportarReservasCsv(arq.toStdString()); } catch (const std::exception& e) { avisoErro(e); } }
void MainWindow::importarAirbnb() { const QString arq = QFileDialog::getOpenFileName(this, "Importar reservas Airbnb", {}, "Texto (*.txt *.csv);;Todos (*)"); if (arq.isEmpty()) return; try { const auto r = gestor_.importarAirbnb(arq.toStdString()); persistir(); atualizarTudo(); QMessageBox::information(this, "Importacao", QString("%1 reserva(s) aceita(s); %2 rejeitada(s).").arg(r.aceitas).arg(r.rejeitadas.size())); } catch (const std::exception& e) { avisoErro(e); } }
