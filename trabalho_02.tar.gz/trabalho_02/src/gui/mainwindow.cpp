#include "mainwindow.h"

#include <QAction>
#include <QCalendarWidget>
#include <QCloseEvent>
#include <QComboBox>
#include <QColor>
#include <QDate>
#include <QDateEdit>
#include <QDoubleSpinBox>
#include <QFileDialog>
#include <QFormLayout>
#include <QFrame>
#include <QGridLayout>
#include <QGroupBox>
#include <QHeaderView>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QLocale>
#include <QMessageBox>
#include <QPlainTextEdit>
#include <QPixmap>
#include <QPushButton>
#include <QSignalBlocker>
#include <QSpinBox>
#include <QStandardPaths>
#include <QTabWidget>
#include <QTableWidget>
#include <QTextCharFormat>
#include <QToolBar>
#include <QVBoxLayout>

#include <algorithm>

namespace {
Data paraData(const QDate& data) { return Data(data.day(), data.month(), data.year()); }
QDate paraQDate(const Data& data) { return QDate(data.ano(), data.mes(), data.dia()); }
QTableWidgetItem* item(const QString& texto, int id = -1) {
    auto* resultado = new QTableWidgetItem(texto);
    if (id >= 0) resultado->setData(Qt::UserRole, id);
    return resultado;
}
// O cartão é um QFrame que contém labels; por isso seu retorno precisa ser
// QWidget*, e não QLabel*. Isso permite inseri-lo corretamente no QGridLayout.
QWidget* cartao(const QString& titulo, QLabel*& valor) {
    auto* caixa = new QFrame; caixa->setObjectName("cartao"); auto* layout = new QVBoxLayout(caixa);
    auto* rotulo = new QLabel(titulo); rotulo->setObjectName("cartaoTitulo"); valor = new QLabel("0"); valor->setObjectName("cartaoValor");
    layout->addWidget(rotulo); layout->addWidget(valor); return caixa;
}
}

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent) {
    diretorioDados_ = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation) + "/dados";
    try { gestor_.carregar(diretorioDados_.toStdString()); } catch (const std::exception& e) { QMessageBox::warning(this, "Dados", e.what()); }
    montarInterface(); atualizarTudo();
}
MainWindow::~MainWindow() = default;

void MainWindow::montarInterface() {
    setWindowTitle("Gestor de Alugueis"); resize(1180, 760); setMinimumSize(880, 570);
    auto* abas = new QTabWidget; setCentralWidget(abas);
    auto* painel = new QWidget; auto* imoveis = new QWidget; auto* reservas = new QWidget; auto* hospedes = new QWidget;
    abas->addTab(painel, "📊 Painel"); abas->addTab(imoveis, "🏠 Imoveis"); abas->addTab(reservas, "📅 Reservas"); abas->addTab(hospedes, "👥 Hospedes");
    // Os métodos montam cada aba sobre o widget criado acima, mantido como filho do QTabWidget.
    painel->setObjectName("abaPainel"); imoveis->setObjectName("abaImoveis"); reservas->setObjectName("abaReservas"); hospedes->setObjectName("abaHospedes");
    montarPainel(); montarImoveis(); montarReservas(); montarHospedes();
    auto* barra = addToolBar("Acoes"); barra->setMovable(false);
    auto* acaoImportar = barra->addAction("Importar Airbnb"); auto* acaoExportar = barra->addAction("Exportar reservas CSV");
    connect(acaoImportar, &QAction::triggered, this, [this] { importarAirbnb(); });
    connect(acaoExportar, &QAction::triggered, this, [this] { exportar(); });
}

void MainWindow::montarPainel() {
    auto* pagina = findChild<QWidget*>("abaPainel"); auto* raiz = new QVBoxLayout(pagina);
    auto* titulo = new QLabel("Painel geral"); titulo->setObjectName("tituloPagina"); raiz->addWidget(titulo);
    auto* grade = new QGridLayout;
    grade->addWidget(cartao("Imoveis cadastrados", cardImoveis_), 0, 0); grade->addWidget(cartao("Hospedes", cardHospedes_), 0, 1); grade->addWidget(cartao("Reservas ativas", cardReservas_), 0, 2);
    grade->addWidget(cartao("Receita do mes", cardReceita_), 1, 0); grade->addWidget(cartao("Ocupacao do mes", cardOcupacao_), 1, 1); grade->addWidget(cartao("A receber", cardReceber_), 1, 2); raiz->addLayout(grade);
    auto* listas = new QHBoxLayout; auto* entradas = new QGroupBox("📥 Proximos check-ins"); auto* saidas = new QGroupBox("📤 Proximos check-outs");
    auto* le = new QVBoxLayout(entradas); auto* ls = new QVBoxLayout(saidas); listaEntradas_ = new QListWidget; listaSaidas_ = new QListWidget; le->addWidget(listaEntradas_); ls->addWidget(listaSaidas_); listas->addWidget(entradas); listas->addWidget(saidas); raiz->addLayout(listas, 1);
}

void MainWindow::montarImoveis() {
    auto* pagina = findChild<QWidget*>("abaImoveis"); auto* raiz = new QHBoxLayout(pagina);
    auto* esquerda = new QVBoxLayout; esquerda->addWidget(new QLabel("Meus imoveis")); tabelaImoveis_ = new QTableWidget(0, 4); tabelaImoveis_->setHorizontalHeaderLabels({"ID", "Imovel", "Diaria", "Capacidade"}); tabelaImoveis_->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch); tabelaImoveis_->setSelectionBehavior(QAbstractItemView::SelectRows); tabelaImoveis_->setEditTriggers(QAbstractItemView::NoEditTriggers); esquerda->addWidget(tabelaImoveis_);
    auto* novo = new QPushButton("Novo imovel"); esquerda->addWidget(novo); raiz->addLayout(esquerda, 3);
    auto* grupo = new QGroupBox("Dados do imovel"); auto* form = new QFormLayout(grupo); fotoImovel_ = new QLabel("Sem foto"); fotoImovel_->setAlignment(Qt::AlignCenter); fotoImovel_->setMinimumHeight(130); fotoImovel_->setObjectName("foto"); form->addRow(fotoImovel_);
    auto* foto = new QPushButton("Escolher foto"); form->addRow(foto); nomeImovel_ = new QLineEdit; enderecoImovel_ = new QLineEdit; diariaImovel_ = new QDoubleSpinBox; diariaImovel_->setMaximum(1000000); diariaImovel_->setPrefix("R$ "); diariaImovel_->setDecimals(2); capacidadeImovel_ = new QSpinBox; capacidadeImovel_->setRange(1, 50); descricaoImovel_ = new QPlainTextEdit; descricaoImovel_->setMaximumHeight(90);
    form->addRow("Nome:", nomeImovel_); form->addRow("Endereco:", enderecoImovel_); form->addRow("Diaria:", diariaImovel_); form->addRow("Capacidade:", capacidadeImovel_); form->addRow("Descricao:", descricaoImovel_);
    auto* salvar = new QPushButton("Salvar"); salvar->setProperty("primario", true); auto* excluir = new QPushButton("Excluir"); auto* acoes = new QHBoxLayout; acoes->addWidget(excluir); acoes->addWidget(salvar); form->addRow(acoes); raiz->addWidget(grupo, 4);
    connect(novo, &QPushButton::clicked, this, [this] { novoImovel(); }); connect(salvar, &QPushButton::clicked, this, [this] { salvarImovel(); }); connect(excluir, &QPushButton::clicked, this, [this] { excluirImovel(); }); connect(foto, &QPushButton::clicked, this, [this] { escolherFoto(); }); connect(tabelaImoveis_, &QTableWidget::itemSelectionChanged, this, [this] { selecionarImovel(); });
}

void MainWindow::montarHospedes() {
    auto* pagina = findChild<QWidget*>("abaHospedes"); auto* raiz = new QHBoxLayout(pagina); auto* esquerda = new QVBoxLayout;
    buscaHospede_ = new QLineEdit; buscaHospede_->setPlaceholderText("Buscar por nome ou documento"); esquerda->addWidget(buscaHospede_); tabelaHospedes_ = new QTableWidget(0, 4); tabelaHospedes_->setHorizontalHeaderLabels({"Nome", "Documento", "Telefone", "E-mail"}); tabelaHospedes_->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch); tabelaHospedes_->setSelectionBehavior(QAbstractItemView::SelectRows); tabelaHospedes_->setEditTriggers(QAbstractItemView::NoEditTriggers); esquerda->addWidget(tabelaHospedes_); auto* novo = new QPushButton("Novo hospede"); esquerda->addWidget(novo); raiz->addLayout(esquerda, 3);
    auto* grupo = new QGroupBox("Dados do hospede"); auto* form = new QFormLayout(grupo); nomeHospede_ = new QLineEdit; docHospede_ = new QLineEdit; telHospede_ = new QLineEdit; emailHospede_ = new QLineEdit; form->addRow("Nome:", nomeHospede_); form->addRow("Documento:", docHospede_); form->addRow("Telefone:", telHospede_); form->addRow("E-mail:", emailHospede_); auto* salvar = new QPushButton("Salvar"); salvar->setProperty("primario", true); auto* excluir = new QPushButton("Excluir"); auto* acoes = new QHBoxLayout; acoes->addWidget(excluir); acoes->addWidget(salvar); form->addRow(acoes); raiz->addWidget(grupo, 2);
    connect(buscaHospede_, &QLineEdit::textChanged, this, [this] { atualizarTabelaHospedes(); }); connect(novo, &QPushButton::clicked, this, [this] { novoHospede(); }); connect(salvar, &QPushButton::clicked, this, [this] { salvarHospede(); }); connect(excluir, &QPushButton::clicked, this, [this] { excluirHospede(); }); connect(tabelaHospedes_, &QTableWidget::itemSelectionChanged, this, [this] { selecionarHospede(); });
}

void MainWindow::montarReservas() {
    auto* pagina = findChild<QWidget*>("abaReservas"); auto* raiz = new QHBoxLayout(pagina); auto* esquerda = new QVBoxLayout;
    imovelReserva_ = new QComboBox; esquerda->addWidget(imovelReserva_); calendario_ = new QCalendarWidget; calendario_->setGridVisible(true); esquerda->addWidget(calendario_); tabelaReservas_ = new QTableWidget(0, 6); tabelaReservas_->setHorizontalHeaderLabels({"Hospede", "Entrada", "Saida", "Canal", "Total", "Status"}); tabelaReservas_->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch); tabelaReservas_->setSelectionBehavior(QAbstractItemView::SelectRows); tabelaReservas_->setEditTriggers(QAbstractItemView::NoEditTriggers); esquerda->addWidget(tabelaReservas_, 2); auto* linha = new QHBoxLayout; auto* concluir = new QPushButton("Concluir"); auto* cancelar = new QPushButton("Cancelar"); auto* exportar = new QPushButton("Exportar CSV"); linha->addWidget(concluir); linha->addWidget(cancelar); linha->addWidget(exportar); esquerda->addLayout(linha); raiz->addLayout(esquerda, 5);
    auto* grupo = new QGroupBox("Nova reserva"); auto* form = new QFormLayout(grupo); hospedeReserva_ = new QComboBox; entradaReserva_ = new QDateEdit(QDate::currentDate()); saidaReserva_ = new QDateEdit(QDate::currentDate().addDays(1)); entradaReserva_->setCalendarPopup(true); saidaReserva_->setCalendarPopup(true); qtdHospedesReserva_ = new QSpinBox; qtdHospedesReserva_->setRange(1, 50); canalReserva_ = new QComboBox; canalReserva_->addItems({"Direto", "Airbnb", "Booking", "WhatsApp", "Outro"}); pagamentoReserva_ = new QComboBox; pagamentoReserva_->addItems({"Pendente", "Sinal pago", "Pago"}); obsReserva_ = new QPlainTextEdit; obsReserva_->setMaximumHeight(75); totalReserva_ = new QLabel("R$ 0,00"); form->addRow("Hospede:", hospedeReserva_); form->addRow("Check-in:", entradaReserva_); form->addRow("Check-out:", saidaReserva_); form->addRow("Quantidade:", qtdHospedesReserva_); form->addRow("Canal:", canalReserva_); form->addRow("Pagamento:", pagamentoReserva_); form->addRow("Observacoes:", obsReserva_); form->addRow("Total:", totalReserva_); auto* registrar = new QPushButton("Registrar reserva"); registrar->setProperty("primario", true); form->addRow(registrar); raiz->addWidget(grupo, 3);
    auto atualizaPreco = [this] { try { totalReserva_->setText(dinheiro(gestor_.preverTotal(imovelReserva_->currentData().toInt(), paraData(entradaReserva_->date()), paraData(saidaReserva_->date())))); } catch (...) { totalReserva_->setText("R$ 0,00"); } };
    connect(imovelReserva_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this, atualizaPreco](int) { atualizarReservas(); atualizaPreco(); }); connect(entradaReserva_, &QDateEdit::dateChanged, this, [atualizaPreco](const QDate&) { atualizaPreco(); }); connect(saidaReserva_, &QDateEdit::dateChanged, this, [atualizaPreco](const QDate&) { atualizaPreco(); }); connect(registrar, &QPushButton::clicked, this, [this] { registrarReserva(); }); connect(concluir, &QPushButton::clicked, this, [this] { mudarStatusSelecionada(StatusReserva::Concluida); }); connect(cancelar, &QPushButton::clicked, this, [this] { mudarStatusSelecionada(StatusReserva::Cancelada); }); connect(exportar, &QPushButton::clicked, this, [this] { this->exportar(); }); connect(tabelaReservas_, &QTableWidget::itemSelectionChanged, this, [this] { selecionarReserva(); });
}

QString MainWindow::dinheiro(double valor) const { return QLocale(QLocale::Portuguese, QLocale::Brazil).toCurrencyString(valor, "R$ "); }
int MainWindow::idImovelSelecionado() const { return tabelaImoveis_->currentRow() < 0 ? -1 : tabelaImoveis_->item(tabelaImoveis_->currentRow(), 0)->data(Qt::UserRole).toInt(); }
int MainWindow::idReservaSelecionada() const { return tabelaReservas_->currentRow() < 0 ? -1 : tabelaReservas_->item(tabelaReservas_->currentRow(), 0)->data(Qt::UserRole).toInt(); }
void MainWindow::avisoErro(const std::exception& erro) { QMessageBox::warning(this, "Operacao nao realizada", erro.what()); }
void MainWindow::persistir() { try { gestor_.salvar(diretorioDados_.toStdString()); } catch (const std::exception& e) { avisoErro(e); } }
void MainWindow::closeEvent(QCloseEvent* event) { persistir(); event->accept(); }

void MainWindow::atualizarTudo() { atualizarTabelaImoveis(); atualizarTabelaHospedes(); atualizarCombos(); atualizarReservas(); atualizarPainel(); }
void MainWindow::atualizarTabelaImoveis() {
    QSignalBlocker bloqueio(tabelaImoveis_); tabelaImoveis_->setRowCount(0); for (const auto& i : gestor_.imoveis()) { int linha = tabelaImoveis_->rowCount(); tabelaImoveis_->insertRow(linha); tabelaImoveis_->setItem(linha, 0, item(QString::number(i.id()), i.id())); tabelaImoveis_->setItem(linha, 1, item(QString::fromStdString(i.nome()))); tabelaImoveis_->setItem(linha, 2, item(dinheiro(i.diaria()))); tabelaImoveis_->setItem(linha, 3, item(QString::number(i.capacidade()))); }
}
void MainWindow::atualizarTabelaHospedes() {
    QSignalBlocker bloqueio(tabelaHospedes_); tabelaHospedes_->setRowCount(0); const QString busca = buscaHospede_->text().trimmed(); for (const auto& h : gestor_.hospedes()) { const QString nome = QString::fromStdString(h.nome()), doc = QString::fromStdString(h.documento()); if (!busca.isEmpty() && !nome.contains(busca, Qt::CaseInsensitive) && !doc.contains(busca, Qt::CaseInsensitive)) continue; int linha = tabelaHospedes_->rowCount(); tabelaHospedes_->insertRow(linha); tabelaHospedes_->setItem(linha, 0, item(nome)); tabelaHospedes_->setItem(linha, 1, item(doc)); tabelaHospedes_->setItem(linha, 2, item(QString::fromStdString(h.telefone()))); tabelaHospedes_->setItem(linha, 3, item(QString::fromStdString(h.email()))); }
}
void MainWindow::atualizarCombos() {
    int selecionado = imovelReserva_->currentData().toInt(); QSignalBlocker b1(imovelReserva_); imovelReserva_->clear(); for (const auto& i : gestor_.imoveis()) imovelReserva_->addItem(QString::fromStdString(i.nome()), i.id()); int indice = imovelReserva_->findData(selecionado); if (indice >= 0) imovelReserva_->setCurrentIndex(indice);
    QString doc = hospedeReserva_->currentData().toString(); QSignalBlocker b2(hospedeReserva_); hospedeReserva_->clear(); for (const auto& h : gestor_.hospedes()) hospedeReserva_->addItem(QString::fromStdString(h.nome() + " — " + h.documento()), QString::fromStdString(h.documento())); indice = hospedeReserva_->findData(doc); if (indice >= 0) hospedeReserva_->setCurrentIndex(indice);
}
void MainWindow::atualizarReservas() {
    QSignalBlocker bloqueio(tabelaReservas_); tabelaReservas_->setRowCount(0); const Imovel* imovel = gestor_.buscarImovel(imovelReserva_->currentData().toInt()); if (!imovel) { atualizarCalendario(); return; } for (const auto& r : imovel->reservas()) { const Hospede* h = gestor_.buscarHospede(r.documentoHospede()); int linha = tabelaReservas_->rowCount(); tabelaReservas_->insertRow(linha); tabelaReservas_->setItem(linha, 0, item(QString::fromStdString(h ? h->nome() : r.documentoHospede()), r.id())); tabelaReservas_->setItem(linha, 1, item(QString::fromStdString(r.checkIn().texto()))); tabelaReservas_->setItem(linha, 2, item(QString::fromStdString(r.checkOut().texto()))); tabelaReservas_->setItem(linha, 3, item(QString::fromStdString(r.canal()))); tabelaReservas_->setItem(linha, 4, item(dinheiro(r.valorBruto()))); tabelaReservas_->setItem(linha, 5, item(QString::fromStdString(textoStatus(r.status())))); } atualizarCalendario();
}
void MainWindow::atualizarCalendario() {
    calendario_->setDateTextFormat(QDate(), QTextCharFormat()); const Imovel* imovel = gestor_.buscarImovel(imovelReserva_->currentData().toInt()); if (!imovel) return; QTextCharFormat ocupado; ocupado.setBackground(QColor("#fecaca")); ocupado.setToolTip("Dia ocupado"); for (const auto& r : imovel->reservas()) { if (r.status() == StatusReserva::Cancelada) continue; for (QDate d = paraQDate(r.checkIn()); d < paraQDate(r.checkOut()); d = d.addDays(1)) calendario_->setDateTextFormat(d, ocupado); }
}
void MainWindow::atualizarPainel() {
    const QDate hoje = QDate::currentDate(); const auto r = gestor_.resumo(hoje.month(), hoje.year()); cardImoveis_->setText(QString::number(r.imoveis)); cardHospedes_->setText(QString::number(r.hospedes)); cardReservas_->setText(QString::number(r.reservasAtivas)); cardReceita_->setText(dinheiro(r.receitaMes)); cardOcupacao_->setText(QString::number(r.ocupacaoMes, 'f', 1) + "%"); cardReceber_->setText(dinheiro(r.aReceber)); listaEntradas_->clear(); listaSaidas_->clear();
    for (const auto& i : gestor_.imoveis()) for (const auto& reserva : i.reservas()) { if (reserva.status() == StatusReserva::Cancelada) continue; const Hospede* h = gestor_.buscarHospede(reserva.documentoHospede()); const QString nome = QString::fromStdString(h ? h->nome() : reserva.documentoHospede()); if (paraQDate(reserva.checkIn()) >= hoje) listaEntradas_->addItem(QString::fromStdString(reserva.checkIn().texto()) + QString(" — %1 (%2)").arg(nome, QString::fromStdString(i.nome()))); if (paraQDate(reserva.checkOut()) >= hoje) listaSaidas_->addItem(QString::fromStdString(reserva.checkOut().texto()) + QString(" — %1 (%2)").arg(nome, QString::fromStdString(i.nome()))); }
}

void MainWindow::novoImovel() { tabelaImoveis_->clearSelection(); nomeImovel_->clear(); enderecoImovel_->clear(); diariaImovel_->setValue(0); capacidadeImovel_->setValue(1); descricaoImovel_->clear(); caminhoFoto_.clear(); fotoImovel_->setPixmap(QPixmap()); fotoImovel_->setText("Sem foto"); nomeImovel_->setFocus(); }
void MainWindow::selecionarImovel() { const Imovel* i = gestor_.buscarImovel(idImovelSelecionado()); if (!i) return; nomeImovel_->setText(QString::fromStdString(i->nome())); enderecoImovel_->setText(QString::fromStdString(i->endereco())); diariaImovel_->setValue(i->diaria()); capacidadeImovel_->setValue(i->capacidade()); descricaoImovel_->setPlainText(QString::fromStdString(i->descricao())); caminhoFoto_ = QString::fromStdString(i->foto()); QPixmap pix(caminhoFoto_); fotoImovel_->setPixmap(pix.scaled(fotoImovel_->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation)); fotoImovel_->setText(pix.isNull() ? "Sem foto" : "");
    // Sincroniza a seleção com a aba de reservas, evitando que o usuário veja
    // o calendário de outro imóvel ao navegar pela tabela.
    const int indice = imovelReserva_->findData(i->id()); if (indice >= 0) imovelReserva_->setCurrentIndex(indice);
}
void MainWindow::escolherFoto() { const QString arquivo = QFileDialog::getOpenFileName(this, "Foto do imovel", {}, "Imagens (*.png *.jpg *.jpeg)"); if (arquivo.isEmpty()) return; caminhoFoto_ = arquivo; QPixmap pix(arquivo); fotoImovel_->setPixmap(pix.scaled(fotoImovel_->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation)); fotoImovel_->setText(""); }
void MainWindow::salvarImovel() { try { int id = idImovelSelecionado(); if (id < 0) id = gestor_.criarImovel(nomeImovel_->text().trimmed().toStdString(), enderecoImovel_->text().trimmed().toStdString(), diariaImovel_->value(), capacidadeImovel_->value(), descricaoImovel_->toPlainText().toStdString(), caminhoFoto_.toStdString()); else gestor_.atualizarImovel(id, nomeImovel_->text().trimmed().toStdString(), enderecoImovel_->text().trimmed().toStdString(), diariaImovel_->value(), capacidadeImovel_->value(), descricaoImovel_->toPlainText().toStdString(), caminhoFoto_.toStdString()); persistir(); atualizarTudo(); for (int linha = 0; linha < tabelaImoveis_->rowCount(); ++linha) if (tabelaImoveis_->item(linha, 0)->data(Qt::UserRole).toInt() == id) tabelaImoveis_->selectRow(linha); } catch (const std::exception& e) { avisoErro(e); } }
void MainWindow::excluirImovel() { try { int id = idImovelSelecionado(); if (id < 0) throw std::runtime_error("Selecione um imovel"); if (QMessageBox::question(this, "Excluir", "Excluir o imovel selecionado?") != QMessageBox::Yes) return; gestor_.excluirImovel(id); persistir(); novoImovel(); atualizarTudo(); } catch (const std::exception& e) { avisoErro(e); } }

void MainWindow::novoHospede() { tabelaHospedes_->clearSelection(); nomeHospede_->clear(); docHospede_->clear(); telHospede_->clear(); emailHospede_->clear(); docHospede_->setReadOnly(false); nomeHospede_->setFocus(); }
void MainWindow::selecionarHospede() { int linha = tabelaHospedes_->currentRow(); if (linha < 0) return; const Hospede* h = gestor_.buscarHospede(tabelaHospedes_->item(linha, 1)->text().toStdString()); if (!h) return; nomeHospede_->setText(QString::fromStdString(h->nome())); docHospede_->setText(QString::fromStdString(h->documento())); telHospede_->setText(QString::fromStdString(h->telefone())); emailHospede_->setText(QString::fromStdString(h->email())); docHospede_->setReadOnly(true); }
void MainWindow::salvarHospede() { try { gestor_.salvarHospede(Hospede(nomeHospede_->text().trimmed().toStdString(), docHospede_->text().trimmed().toStdString(), telHospede_->text().trimmed().toStdString(), emailHospede_->text().trimmed().toStdString())); persistir(); atualizarTudo(); } catch (const std::exception& e) { avisoErro(e); } }
void MainWindow::excluirHospede() { try { int linha = tabelaHospedes_->currentRow(); if (linha < 0) throw std::runtime_error("Selecione um hospede"); const std::string doc = tabelaHospedes_->item(linha, 1)->text().toStdString(); if (QMessageBox::question(this, "Excluir", "Excluir o hospede selecionado?") != QMessageBox::Yes) return; gestor_.excluirHospede(doc); persistir(); novoHospede(); atualizarTudo(); } catch (const std::exception& e) { avisoErro(e); } }

void MainWindow::registrarReserva() { try { const int id = imovelReserva_->currentData().toInt(); if (id <= 0 || hospedeReserva_->currentData().toString().isEmpty()) throw std::runtime_error("Cadastre e selecione um imovel e um hospede"); gestor_.registrarReserva(id, hospedeReserva_->currentData().toString().toStdString(), paraData(entradaReserva_->date()), paraData(saidaReserva_->date()), qtdHospedesReserva_->value(), canalReserva_->currentText().toStdString(), pagamentoReserva_->currentText().toStdString(), obsReserva_->toPlainText().toStdString()); persistir(); obsReserva_->clear(); atualizarTudo(); QMessageBox::information(this, "Reserva confirmada", "Reserva cadastrada e datas bloqueadas nos demais canais."); } catch (const std::exception& e) { avisoErro(e); } }
void MainWindow::selecionarReserva() { /* A seleção é usada pelos botões Concluir e Cancelar. */ }
void MainWindow::mudarStatusSelecionada(StatusReserva status) { try { int id = idReservaSelecionada(); if (id < 0) throw std::runtime_error("Selecione uma reserva"); gestor_.mudarStatusReserva(imovelReserva_->currentData().toInt(), id, status); persistir(); atualizarTudo(); } catch (const std::exception& e) { avisoErro(e); } }
void MainWindow::exportar() { const QString arquivo = QFileDialog::getSaveFileName(this, "Exportar reservas", "reservas_exportadas.csv", "CSV (*.csv)"); if (arquivo.isEmpty()) return; try { gestor_.exportarReservasCsv(arquivo.toStdString()); QMessageBox::information(this, "Exportacao", "CSV exportado com sucesso."); } catch (const std::exception& e) { avisoErro(e); } }
void MainWindow::importarAirbnb() { const QString arquivo = QFileDialog::getOpenFileName(this, "Importar reservas Airbnb", {}, "Texto (*.txt *.csv);;Todos (*)"); if (arquivo.isEmpty()) return; try { const auto r = gestor_.importarAirbnb(arquivo.toStdString()); persistir(); atualizarTudo(); QString mensagem = QString("%1 reserva(s) aceita(s).").arg(r.aceitas); if (!r.rejeitadas.empty()) { mensagem += "\n\nRejeitadas:\n"; for (const auto& erro : r.rejeitadas) mensagem += QString::fromStdString(erro) + '\n'; } QMessageBox::information(this, "Importacao Airbnb", mensagem); } catch (const std::exception& e) { avisoErro(e); } }
