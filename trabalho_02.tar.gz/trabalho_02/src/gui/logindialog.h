#pragma once

#include <QDialog>

class QLineEdit;
class QLabel;

class LoginDialog : public QDialog {
public:
    explicit LoginDialog(QWidget* parent = nullptr);
private:
    void entrar();
    QLineEdit* usuario_;
    QLineEdit* senha_;
    QLabel* aviso_;
};
