#pragma once

#include <QDialog>

namespace Ui { class LoginDialog; }

class LoginDialog : public QDialog {
public:
    explicit LoginDialog(QWidget* parent = nullptr);
    ~LoginDialog() override;
private:
    void entrar();
    Ui::LoginDialog* ui;
};
