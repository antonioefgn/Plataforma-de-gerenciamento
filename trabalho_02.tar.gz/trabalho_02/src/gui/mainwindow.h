#pragma once

#include "domain/gerenciador.h"

#include <QMainWindow>

class QCalendarWidget;
class QComboBox;
class QDateEdit;
class QDoubleSpinBox;
class QLineEdit;
class QLabel;
class QListWidget;
class QPlainTextEdit;
class QSpinBox;
class QTableWidget;

class MainWindow : public QMainWindow {
public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow() override;

protected:
    void closeEvent(QCloseEvent* event) override;

private:
    void montarInterface();
    void montarPainel(); void montarImoveis(); void montarHospedes(); void montarReservas();
    void atualizarTudo(); void atualizarPainel(); void atualizarTabelaImoveis(); void atualizarTabelaHospedes();
    void atualizarCombos(); void atualizarReservas(); void atualizarCalendario();
    void novoImovel(); void salvarImovel(); void selecionarImovel(); void excluirImovel(); void escolherFoto();
    void novoHospede(); void salvarHospede(); void selecionarHospede(); void excluirHospede();
    void registrarReserva(); void selecionarReserva(); void mudarStatusSelecionada(StatusReserva status); void exportar(); void importarAirbnb();
    int idImovelSelecionado() const; int idReservaSelecionada() const; QString dinheiro(double valor) const;
    void persistir(); void avisoErro(const std::exception& erro);

    GerenciadorCanais gestor_;
    QString diretorioDados_;
    QTableWidget *tabelaImoveis_ = nullptr, *tabelaHospedes_ = nullptr, *tabelaReservas_ = nullptr;
    QLineEdit *nomeImovel_ = nullptr, *enderecoImovel_ = nullptr, *nomeHospede_ = nullptr, *docHospede_ = nullptr, *telHospede_ = nullptr, *emailHospede_ = nullptr, *buscaHospede_ = nullptr;
    QDoubleSpinBox* diariaImovel_ = nullptr;
    QSpinBox *capacidadeImovel_ = nullptr, *qtdHospedesReserva_ = nullptr;
    QPlainTextEdit *descricaoImovel_ = nullptr, *obsReserva_ = nullptr;
    QLabel *fotoImovel_ = nullptr, *totalReserva_ = nullptr;
    QString caminhoFoto_;
    QComboBox *imovelReserva_ = nullptr, *hospedeReserva_ = nullptr, *canalReserva_ = nullptr, *pagamentoReserva_ = nullptr;
    QDateEdit *entradaReserva_ = nullptr, *saidaReserva_ = nullptr;
    QCalendarWidget* calendario_ = nullptr;
    QLabel *cardImoveis_ = nullptr, *cardHospedes_ = nullptr, *cardReservas_ = nullptr, *cardReceita_ = nullptr, *cardOcupacao_ = nullptr, *cardReceber_ = nullptr;
    QListWidget *listaEntradas_ = nullptr, *listaSaidas_ = nullptr;
};
