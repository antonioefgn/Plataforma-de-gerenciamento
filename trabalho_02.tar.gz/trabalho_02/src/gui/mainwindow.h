#pragma once

#include "domain/gerenciador.h"

#include <QMainWindow>

class QCloseEvent;
namespace Ui { class MainWindow; }

// O layout inteiro está em mainwindow.ui. Esta classe mantém somente a lógica
// que reage aos botões e preenche os widgets criados pelo Qt Designer.
class MainWindow : public QMainWindow {
public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow() override;

protected:
    void closeEvent(QCloseEvent* event) override;

private:
    void conectarEventos();
    void atualizarTudo();
    void atualizarTabelaImoveis(); void atualizarTabelaHospedes(); void atualizarCombos();
    void atualizarReservas(); void atualizarCalendario(); void atualizarPainel();
    void novoImovel(); void salvarImovel(); void selecionarImovel(); void excluirImovel(); void escolherFoto();
    void novoHospede(); void salvarHospede(); void selecionarHospede(); void excluirHospede();
    void registrarReserva(); void mudarStatusSelecionada(StatusReserva status); void exportar(); void importarAirbnb();
    int idImovelSelecionado() const; int idReservaSelecionada() const; QString dinheiro(double valor) const;
    void persistir(); void avisoErro(const std::exception& erro);

    Ui::MainWindow* ui;
    GerenciadorCanais gestor_;
    QString diretorioDados_;
    QString caminhoFoto_;
};
