#include "logindialog.h"

#include <QCheckBox>
#include <QFormLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>

LoginDialog::LoginDialog(QWidget* parent) : QDialog(parent) {
    setWindowTitle("Acesso - Gestor de Alugueis"); setMinimumWidth(370);
    auto* raiz = new QVBoxLayout(this);
    auto* titulo = new QLabel("Gestor de Alugueis"); titulo->setObjectName("titulo"); raiz->addWidget(titulo);
    raiz->addWidget(new QLabel("Entre para administrar seus imoveis e reservas."));
    auto* formulario = new QFormLayout; usuario_ = new QLineEdit; senha_ = new QLineEdit; senha_->setEchoMode(QLineEdit::Password);
    formulario->addRow("Usuario:", usuario_); formulario->addRow("Senha:", senha_); raiz->addLayout(formulario);
    auto* mostrar = new QCheckBox("Mostrar senha"); raiz->addWidget(mostrar);
    aviso_ = new QLabel; aviso_->setStyleSheet("color:#b91c1c;"); raiz->addWidget(aviso_);
    auto* botao = new QPushButton("Entrar"); botao->setProperty("primario", true); raiz->addWidget(botao);
    connect(mostrar, &QCheckBox::toggled, this, [this](bool marcado) { senha_->setEchoMode(marcado ? QLineEdit::Normal : QLineEdit::Password); });
    connect(botao, &QPushButton::clicked, this, [this] { entrar(); }); connect(senha_, &QLineEdit::returnPressed, this, [this] { entrar(); });
    usuario_->setFocus();
}
void LoginDialog::entrar() {
    // Credenciais didáticas: em um produto real, senha deve estar protegida no servidor.
    if (usuario_->text().trimmed() == "admin" && senha_->text() == "1234") { accept(); return; }
    aviso_->setText("Usuario ou senha incorretos."); senha_->clear(); senha_->setFocus();
}
