#include "logindialog.h"
#include "ui_logindialog.h"

#include <QCheckBox>
#include <QFormLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>

LoginDialog::LoginDialog(QWidget* parent) : QDialog(parent), ui(new Ui::LoginDialog) {
    ui->setupUi(this);
    // O Qt Designer define os widgets; o C++ fica responsável somente pelos eventos.
    connect(ui->chkMostrarSenha, &QCheckBox::toggled, this, [this](bool marcado) { ui->editSenha->setEchoMode(marcado ? QLineEdit::Normal : QLineEdit::Password); });
    connect(ui->btnEntrar, &QPushButton::clicked, this, [this] { entrar(); }); connect(ui->editSenha, &QLineEdit::returnPressed, this, [this] { entrar(); });
    ui->editUsuario->setFocus();
}
LoginDialog::~LoginDialog() { delete ui; }
void LoginDialog::entrar() {
    // Credenciais didáticas: em um produto real, senha deve estar protegida no servidor.
    if (ui->editUsuario->text().trimmed() == "admin" && ui->editSenha->text() == "1234") { accept(); return; }
    ui->erro->setText("Usuario ou senha incorretos."); ui->editSenha->clear(); ui->editSenha->setFocus();
}
