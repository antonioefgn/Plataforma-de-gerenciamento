#pragma once

#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <string>

// Tipo de data independente do Qt. Manter a regra de negócio sem dependência
// da interface torna possível testá-la também em um programa de console.
class Data {
public:
    Data() = default;
    Data(int dia, int mes, int ano) : dia_(dia), mes_(mes), ano_(ano) {
        if (!valida()) throw std::invalid_argument("Data invalida");
    }

    int dia() const { return dia_; }
    int mes() const { return mes_; }
    int ano() const { return ano_; }

    bool valida() const {
        if (ano_ < 1900 || mes_ < 1 || mes_ > 12 || dia_ < 1) return false;
        static const int diasPorMes[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
        int limite = diasPorMes[mes_];
        if (mes_ == 2 && bissexto(ano_)) limite = 29;
        return dia_ <= limite;
    }

    std::string texto() const {
        std::ostringstream saida;
        saida << std::setfill('0') << std::setw(2) << dia_ << '/'
              << std::setw(2) << mes_ << '/' << std::setw(4) << ano_;
        return saida.str();
    }

    // Formato ISO é ótimo para CSV: ordena alfabeticamente na mesma ordem cronológica.
    std::string iso() const {
        std::ostringstream saida;
        saida << std::setfill('0') << std::setw(4) << ano_ << '-'
              << std::setw(2) << mes_ << '-' << std::setw(2) << dia_;
        return saida.str();
    }

    // Número crescente de dias. É usado para precificar a estadia sem depender
    // de fuso horário nem de QDate. O algoritmo usa o calendário gregoriano.
    int numeroSerial() const {
        int y = ano_;
        const unsigned m = static_cast<unsigned>(mes_);
        const unsigned d = static_cast<unsigned>(dia_);
        y -= m <= 2;
        const int era = (y >= 0 ? y : y - 399) / 400;
        const unsigned anoDaEra = static_cast<unsigned>(y - era * 400);
        const unsigned diaDoAno = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
        const unsigned diaDaEra = anoDaEra * 365 + anoDaEra / 4 - anoDaEra / 100 + diaDoAno;
        return era * 146097 + static_cast<int>(diaDaEra);
    }

    static Data deIso(const std::string& valor) {
        if (valor.size() != 10 || valor[4] != '-' || valor[7] != '-')
            throw std::invalid_argument("Data ISO invalida: " + valor);
        return Data(std::stoi(valor.substr(8, 2)), std::stoi(valor.substr(5, 2)),
                    std::stoi(valor.substr(0, 4)));
    }

    friend bool operator==(const Data& a, const Data& b) { return a.chave() == b.chave(); }
    friend bool operator!=(const Data& a, const Data& b) { return !(a == b); }
    friend bool operator<(const Data& a, const Data& b) { return a.chave() < b.chave(); }
    friend bool operator<=(const Data& a, const Data& b) { return !(b < a); }
    friend bool operator>(const Data& a, const Data& b) { return b < a; }
    friend bool operator>=(const Data& a, const Data& b) { return !(a < b); }

private:
    int dia_ = 1, mes_ = 1, ano_ = 2000;
    int chave() const { return ano_ * 10000 + mes_ * 100 + dia_; }
    static bool bissexto(int ano) { return ano % 400 == 0 || (ano % 4 == 0 && ano % 100 != 0); }
};
