#pragma once

#include "reserva.h"

#include <algorithm>
#include <stdexcept>
#include <string>
#include <vector>

class Imovel {
public:
    Imovel() = default;
    Imovel(int id, std::string nome, std::string endereco, double diaria, int capacidade,
           std::string descricao = {}, std::string foto = {})
        : id_(id), nome_(std::move(nome)), endereco_(std::move(endereco)), diaria_(diaria),
          capacidade_(capacidade), descricao_(std::move(descricao)), foto_(std::move(foto)) {
        if (id_ <= 0 || nome_.empty() || diaria_ < 0 || capacidade_ < 1)
            throw std::invalid_argument("Dados invalidos do imovel");
    }
    int id() const { return id_; }
    const std::string& nome() const { return nome_; }
    const std::string& endereco() const { return endereco_; }
    double diaria() const { return diaria_; }
    int capacidade() const { return capacidade_; }
    const std::string& descricao() const { return descricao_; }
    const std::string& foto() const { return foto_; }
    const std::vector<Reserva>& reservas() const { return reservas_; }
    std::vector<Reserva>& reservas() { return reservas_; }
    void atualizar(std::string nome, std::string endereco, double diaria, int capacidade, std::string descricao, std::string foto) {
        if (nome.empty() || diaria < 0 || capacidade < 1) throw std::invalid_argument("Dados invalidos do imovel");
        nome_ = std::move(nome); endereco_ = std::move(endereco); diaria_ = diaria; capacidade_ = capacidade;
        descricao_ = std::move(descricao); foto_ = std::move(foto);
    }
    void adicionarReserva(const Reserva& nova) {
        if (nova.quantidadeHospedes() > capacidade_) throw std::runtime_error("Quantidade de hospedes excede a capacidade");
        const bool existeConflito = std::any_of(reservas_.begin(), reservas_.end(),
            [&](const Reserva& atual) { return atual.conflitaCom(nova); });
        if (existeConflito) throw std::runtime_error("Conflito de datas: o imovel ja esta reservado nesse periodo");
        reservas_.push_back(nova);
    }
private:
    int id_ = 0;
    std::string nome_, endereco_;
    double diaria_ = 0.0;
    int capacidade_ = 1;
    std::string descricao_, foto_;
    std::vector<Reserva> reservas_;
};
