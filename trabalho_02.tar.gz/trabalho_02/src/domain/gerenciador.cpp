#include "gerenciador.h"

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>

GerenciadorCanais::GerenciadorCanais() {
    plataformas_.push_back(std::make_unique<Airbnb>());
    plataformas_.push_back(std::make_unique<Booking>());
    plataformas_.push_back(std::make_unique<ReservaDireta>());
    plataformas_.push_back(std::make_unique<CanalGenerico>("WhatsApp"));
    plataformas_.push_back(std::make_unique<CanalGenerico>("Outro"));
}

Imovel* GerenciadorCanais::buscarImovel(int id) {
    const auto it = std::find_if(imoveis_.begin(), imoveis_.end(), [id](const Imovel& i) { return i.id() == id; });
    return it == imoveis_.end() ? nullptr : &*it;
}
const Imovel* GerenciadorCanais::buscarImovel(int id) const { return const_cast<GerenciadorCanais*>(this)->buscarImovel(id); }
Hospede* GerenciadorCanais::buscarHospede(const std::string& documento) {
    const auto it = std::find_if(hospedes_.begin(), hospedes_.end(), [&](const Hospede& h) { return h.documento() == documento; });
    return it == hospedes_.end() ? nullptr : &*it;
}
const Hospede* GerenciadorCanais::buscarHospede(const std::string& documento) const { return const_cast<GerenciadorCanais*>(this)->buscarHospede(documento); }

int GerenciadorCanais::criarImovel(const std::string& nome, const std::string& endereco, double diaria, int capacidade,
                                   const std::string& descricao, const std::string& foto) {
    imoveis_.emplace_back(proximoIdImovel_, nome, endereco, diaria, capacidade, descricao, foto);
    return proximoIdImovel_++;
}
void GerenciadorCanais::atualizarImovel(int id, const std::string& nome, const std::string& endereco, double diaria,
                                        int capacidade, const std::string& descricao, const std::string& foto) {
    Imovel* imovel = buscarImovel(id);
    if (!imovel) throw std::runtime_error("Imovel nao encontrado");
    imovel->atualizar(nome, endereco, diaria, capacidade, descricao, foto);
}
void GerenciadorCanais::excluirImovel(int id) {
    const auto it = std::find_if(imoveis_.begin(), imoveis_.end(), [id](const Imovel& i) { return i.id() == id; });
    if (it == imoveis_.end()) throw std::runtime_error("Imovel nao encontrado");
    if (!it->reservas().empty()) throw std::runtime_error("Nao e possivel excluir um imovel com reservas");
    imoveis_.erase(it);
}
void GerenciadorCanais::salvarHospede(const Hospede& hospede) {
    Hospede* existente = buscarHospede(hospede.documento());
    if (existente) *existente = hospede; else hospedes_.push_back(hospede);
}
void GerenciadorCanais::excluirHospede(const std::string& documento) {
    for (const auto& imovel : imoveis_)
        for (const auto& reserva : imovel.reservas())
            if (reserva.documentoHospede() == documento)
                throw std::runtime_error("Nao e possivel excluir hospede com historico de reservas");
    const auto it = std::find_if(hospedes_.begin(), hospedes_.end(), [&](const Hospede& h) { return h.documento() == documento; });
    if (it == hospedes_.end()) throw std::runtime_error("Hospede nao encontrado");
    hospedes_.erase(it);
}

double GerenciadorCanais::preverTotal(int idImovel, Data entrada, Data saida) const {
    const Imovel* imovel = buscarImovel(idImovel);
    if (!imovel) throw std::runtime_error("Imovel nao encontrado");
    if (!(entrada < saida)) throw std::invalid_argument("Check-out deve ser posterior ao check-in");
    return (saida.numeroSerial() - entrada.numeroSerial()) * imovel->diaria();
}
int GerenciadorCanais::registrarReserva(int idImovel, const std::string& documentoHospede, Data entrada, Data saida,
                                        int quantidadeHospedes, const std::string& canal, const std::string& pagamento,
                                        const std::string& observacoes) {
    Imovel* imovel = buscarImovel(idImovel);
    if (!imovel) throw std::runtime_error("Imovel nao encontrado");
    if (!buscarHospede(documentoHospede)) throw std::runtime_error("Hospede nao encontrado");
    if (!plataforma(canal)) throw std::runtime_error("Canal de reserva invalido");
    const double total = preverTotal(idImovel, entrada, saida);
    Reserva reserva(proximoIdReserva_, documentoHospede, entrada, saida, quantidadeHospedes, canal, pagamento, observacoes, total);
    imovel->adicionarReserva(reserva);
    return proximoIdReserva_++;
}
void GerenciadorCanais::mudarStatusReserva(int idImovel, int idReserva, StatusReserva status) {
    Imovel* imovel = buscarImovel(idImovel);
    if (!imovel) throw std::runtime_error("Imovel nao encontrado");
    for (Reserva& reserva : imovel->reservas()) if (reserva.id() == idReserva) { reserva.definirStatus(status); return; }
    throw std::runtime_error("Reserva nao encontrada");
}
void GerenciadorCanais::excluirReserva(int idImovel, int idReserva) {
    Imovel* imovel = buscarImovel(idImovel);
    if (!imovel) throw std::runtime_error("Imovel nao encontrado");
    auto& reservas = imovel->reservas();
    const auto it = std::find_if(reservas.begin(), reservas.end(), [idReserva](const Reserva& r) { return r.id() == idReserva; });
    if (it == reservas.end()) throw std::runtime_error("Reserva nao encontrada");
    reservas.erase(it);
}
const Plataforma* GerenciadorCanais::plataforma(const std::string& nome) const {
    for (const auto& item : plataformas_) if (item->nome() == nome) return item.get();
    return nullptr;
}
double GerenciadorCanais::valorLiquido(const Reserva& reserva) const {
    const Plataforma* canal = plataforma(reserva.canal());
    return canal ? canal->valorLiquido(reserva.valorBruto()) : reserva.valorBruto();
}
ResumoFinanceiro GerenciadorCanais::resumo(int mes, int ano) const {
    ResumoFinanceiro resultado;
    resultado.imoveis = static_cast<int>(imoveis_.size());
    resultado.hospedes = static_cast<int>(hospedes_.size());
    int noitesOcupadas = 0;
    for (const auto& imovel : imoveis_) for (const auto& reserva : imovel.reservas()) {
        if (reserva.status() == StatusReserva::Cancelada) continue;
        ++resultado.reservasAtivas;
        if (reserva.checkIn().mes() == mes && reserva.checkIn().ano() == ano) {
            resultado.receitaMes += valorLiquido(reserva);
            noitesOcupadas += reserva.checkOut().numeroSerial() - reserva.checkIn().numeroSerial();
            if (reserva.pagamento() != "Pago") resultado.aReceber += reserva.valorBruto();
        }
    }
    int diasNoMes = Data(1, mes == 12 ? 1 : mes + 1, mes == 12 ? ano + 1 : ano).numeroSerial() - Data(1, mes, ano).numeroSerial();
    resultado.ocupacaoMes = imoveis_.empty() ? 0.0 : (100.0 * noitesOcupadas / (diasNoMes * imoveis_.size()));
    return resultado;
}

std::string GerenciadorCanais::limparCampo(std::string texto) {
    std::replace(texto.begin(), texto.end(), ';', ',');
    std::replace(texto.begin(), texto.end(), '\n', ' ');
    std::replace(texto.begin(), texto.end(), '\r', ' ');
    return texto;
}
std::vector<std::string> GerenciadorCanais::separar(const std::string& linha) {
    std::vector<std::string> itens; std::stringstream fluxo(linha); std::string item;
    while (std::getline(fluxo, item, ';')) itens.push_back(item);
    // getline não devolve o último campo vazio quando a linha termina em ';'.
    // Sem este ajuste, uma foto/e-mail em branco deslocaria ou invalidaria o CSV.
    if (!linha.empty() && linha.back() == ';') itens.emplace_back();
    return itens;
}
void GerenciadorCanais::salvar(const std::string& diretorio) const {
    std::filesystem::create_directories(diretorio);
    std::ofstream arqImoveis(diretorio + "/imoveis.csv"), arqHospedes(diretorio + "/hospedes.csv"), arqReservas(diretorio + "/reservas.csv");
    if (!arqImoveis || !arqHospedes || !arqReservas) throw std::runtime_error("Nao foi possivel gravar os arquivos CSV");
    arqImoveis << "id;nome;endereco;diaria;capacidade;descricao;foto\n";
    arqImoveis << std::fixed << std::setprecision(2);
    for (const auto& i : imoveis_) arqImoveis << i.id() << ';' << limparCampo(i.nome()) << ';' << limparCampo(i.endereco()) << ';' << i.diaria() << ';' << i.capacidade() << ';' << limparCampo(i.descricao()) << ';' << limparCampo(i.foto()) << '\n';
    arqHospedes << "nome;documento;telefone;email\n";
    for (const auto& h : hospedes_) arqHospedes << limparCampo(h.nome()) << ';' << limparCampo(h.documento()) << ';' << limparCampo(h.telefone()) << ';' << limparCampo(h.email()) << '\n';
    arqReservas << "id;imovel;documento;entrada;saida;quantidade;canal;pagamento;observacoes;valor;status\n";
    arqReservas << std::fixed << std::setprecision(2);
    for (const auto& i : imoveis_) for (const auto& r : i.reservas())
        arqReservas << r.id() << ';' << i.id() << ';' << limparCampo(r.documentoHospede()) << ';' << r.checkIn().iso() << ';' << r.checkOut().iso() << ';' << r.quantidadeHospedes() << ';' << limparCampo(r.canal()) << ';' << limparCampo(r.pagamento()) << ';' << limparCampo(r.observacoes()) << ';' << r.valorBruto() << ';' << textoStatus(r.status()) << '\n';
}
void GerenciadorCanais::carregar(const std::string& diretorio) {
    imoveis_.clear(); hospedes_.clear(); proximoIdImovel_ = 1; proximoIdReserva_ = 1;
    std::ifstream arqImoveis(diretorio + "/imoveis.csv"); std::string linha;
    if (arqImoveis && std::getline(arqImoveis, linha)) while (std::getline(arqImoveis, linha)) {
        const auto c = separar(linha); if (c.size() != 7) continue;
        const int id = std::stoi(c[0]); imoveis_.emplace_back(id, c[1], c[2], std::stod(c[3]), std::stoi(c[4]), c[5], c[6]); proximoIdImovel_ = std::max(proximoIdImovel_, id + 1);
    }
    std::ifstream arqHospedes(diretorio + "/hospedes.csv");
    if (arqHospedes && std::getline(arqHospedes, linha)) while (std::getline(arqHospedes, linha)) { const auto c = separar(linha); if (c.size() == 4) hospedes_.emplace_back(c[0], c[1], c[2], c[3]); }
    std::ifstream arqReservas(diretorio + "/reservas.csv");
    if (arqReservas && std::getline(arqReservas, linha)) while (std::getline(arqReservas, linha)) {
        const auto c = separar(linha); if (c.size() != 11) continue;
        Imovel* i = buscarImovel(std::stoi(c[1])); if (!i) continue;
        const int id = std::stoi(c[0]); i->reservas().emplace_back(id, c[2], Data::deIso(c[3]), Data::deIso(c[4]), std::stoi(c[5]), c[6], c[7], c[8], std::stod(c[9]), statusDeTexto(c[10])); proximoIdReserva_ = std::max(proximoIdReserva_, id + 1);
    }
}
void GerenciadorCanais::exportarReservasCsv(const std::string& arquivo) const {
    std::ofstream saida(arquivo); if (!saida) throw std::runtime_error("Nao foi possivel exportar o CSV");
    saida << "id;imovel;hospede;entrada;saida;canal;pagamento;valor_bruto;valor_liquido;status\n";
    saida << std::fixed << std::setprecision(2);
    for (const auto& i : imoveis_) for (const auto& r : i.reservas()) {
        const Hospede* h = buscarHospede(r.documentoHospede());
        saida << r.id() << ';' << limparCampo(i.nome()) << ';' << limparCampo(h ? h->nome() : r.documentoHospede()) << ';' << r.checkIn().iso() << ';' << r.checkOut().iso() << ';' << r.canal() << ';' << r.pagamento() << ';' << r.valorBruto() << ';' << valorLiquido(r) << ';' << textoStatus(r.status()) << '\n';
    }
}
ResultadoImportacao GerenciadorCanais::importarAirbnb(const std::string& arquivo) {
    std::ifstream entrada(arquivo); if (!entrada) throw std::runtime_error("Nao foi possivel abrir o arquivo de importacao");
    ResultadoImportacao resultado; std::string linha; int numeroLinha = 0;
    while (std::getline(entrada, linha)) { ++numeroLinha; if (linha.empty() || linha[0] == '#') continue; const auto c = separar(linha);
        try {
            if (c.size() != 12) throw std::runtime_error("esperados 12 campos separados por ;");
            const int idImovel = std::stoi(c[0]);
            if (!buscarHospede(c[8])) salvarHospede(Hospede(c[7], c[8], c[9], c[10]));
            const Data in(std::stoi(c[1]), std::stoi(c[2]), std::stoi(c[3])), out(std::stoi(c[4]), std::stoi(c[5]), std::stoi(c[6]));
            Imovel* imovel = buscarImovel(idImovel); if (!imovel) throw std::runtime_error("imovel inexistente");
            const double valor = std::stod(c[11]);
            Reserva reserva(proximoIdReserva_, c[8], in, out, 1, "Airbnb", "Pendente", "Importada do Airbnb", valor);
            imovel->adicionarReserva(reserva); ++proximoIdReserva_; ++resultado.aceitas;
        } catch (const std::exception& e) { resultado.rejeitadas.push_back("Linha " + std::to_string(numeroLinha) + ": " + e.what()); }
    }
    return resultado;
}
