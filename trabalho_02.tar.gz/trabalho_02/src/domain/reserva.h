#pragma once

#include "data.h"

#include <stdexcept>
#include <string>

enum class StatusReserva { Confirmada, Concluida, Cancelada };

inline std::string textoStatus(StatusReserva status) {
    switch (status) {
    case StatusReserva::Confirmada: return "Confirmada";
    case StatusReserva::Concluida: return "Concluida";
    case StatusReserva::Cancelada: return "Cancelada";
    }
    return "Confirmada";
}

inline StatusReserva statusDeTexto(const std::string& valor) {
    if (valor == "Concluida") return StatusReserva::Concluida;
    if (valor == "Cancelada") return StatusReserva::Cancelada;
    return StatusReserva::Confirmada;
}

class Reserva {
public:
    Reserva() = default;
    Reserva(int id, std::string documentoHospede, Data checkIn, Data checkOut, int quantidadeHospedes,
            std::string canal, std::string pagamento, std::string observacoes, double valorBruto,
            StatusReserva status = StatusReserva::Confirmada)
        : id_(id), documentoHospede_(std::move(documentoHospede)), checkIn_(checkIn), checkOut_(checkOut),
          quantidadeHospedes_(quantidadeHospedes), canal_(std::move(canal)), pagamento_(std::move(pagamento)),
          observacoes_(std::move(observacoes)), valorBruto_(valorBruto), status_(status) {
        if (id_ <= 0 || documentoHospede_.empty() || !(checkIn_ < checkOut_) || quantidadeHospedes_ < 1 || valorBruto_ < 0)
            throw std::invalid_argument("Dados invalidos da reserva");
    }

    int id() const { return id_; }
    const std::string& documentoHospede() const { return documentoHospede_; }
    const Data& checkIn() const { return checkIn_; }
    const Data& checkOut() const { return checkOut_; }
    int quantidadeHospedes() const { return quantidadeHospedes_; }
    const std::string& canal() const { return canal_; }
    const std::string& pagamento() const { return pagamento_; }
    const std::string& observacoes() const { return observacoes_; }
    double valorBruto() const { return valorBruto_; }
    StatusReserva status() const { return status_; }
    void definirStatus(StatusReserva status) { status_ = status; }

    // Check-out e check-in no mesmo dia são permitidos: não há pernoite em comum.
    bool conflitaCom(const Reserva& outra) const {
        if (status_ == StatusReserva::Cancelada || outra.status_ == StatusReserva::Cancelada) return false;
        return checkIn_ < outra.checkOut_ && checkOut_ > outra.checkIn_;
    }

private:
    int id_ = 0;
    std::string documentoHospede_;
    Data checkIn_, checkOut_;
    int quantidadeHospedes_ = 1;
    std::string canal_, pagamento_, observacoes_;
    double valorBruto_ = 0.0;
    StatusReserva status_ = StatusReserva::Confirmada;
};
