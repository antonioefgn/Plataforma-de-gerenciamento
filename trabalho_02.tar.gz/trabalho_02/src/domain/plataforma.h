#pragma once

#include <algorithm>
#include <memory>
#include <string>

// Exemplo explícito de polimorfismo: o gerenciador não precisa saber a regra
// de comissão de cada canal, apenas pede o valor líquido à classe base.
class Plataforma {
public:
    virtual ~Plataforma() = default;
    virtual std::string nome() const = 0;
    virtual double valorLiquido(double bruto) const = 0;
};

class Airbnb final : public Plataforma {
public:
    std::string nome() const override { return "Airbnb"; }
    double valorLiquido(double bruto) const override { return bruto * 0.85; }
};

class Booking final : public Plataforma {
public:
    std::string nome() const override { return "Booking"; }
    double valorLiquido(double bruto) const override { return std::max(0.0, bruto * 0.88 - 80.0); }
};

class ReservaDireta final : public Plataforma {
public:
    std::string nome() const override { return "Direto"; }
    double valorLiquido(double bruto) const override { return bruto; }
};

// Canais sem comissão conhecida continuam registráveis (WhatsApp, outro).
class CanalGenerico final : public Plataforma {
public:
    explicit CanalGenerico(std::string nome) : nome_(std::move(nome)) {}
    std::string nome() const override { return nome_; }
    double valorLiquido(double bruto) const override { return bruto; }
private:
    std::string nome_;
};
