#pragma once

#include <stdexcept>
#include <string>

class Hospede {
public:
    Hospede() = default;
    Hospede(std::string nome, std::string documento, std::string telefone, std::string email)
        : nome_(std::move(nome)), documento_(std::move(documento)), telefone_(std::move(telefone)), email_(std::move(email)) {
        if (nome_.empty() || documento_.empty())
            throw std::invalid_argument("Nome e documento do hospede sao obrigatorios");
    }
    const std::string& nome() const { return nome_; }
    const std::string& documento() const { return documento_; }
    const std::string& telefone() const { return telefone_; }
    const std::string& email() const { return email_; }

private:
    std::string nome_, documento_, telefone_, email_;
};
