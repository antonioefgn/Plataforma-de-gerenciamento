#pragma once

#include "hospede.h"
#include "imovel.h"
#include "plataforma.h"

#include <memory>
#include <string>
#include <vector>

struct ResumoFinanceiro {
    int imoveis = 0;
    int hospedes = 0;
    int reservasAtivas = 0;
    double receitaMes = 0.0;
    double aReceber = 0.0;
    double ocupacaoMes = 0.0;
};

struct ResultadoImportacao {
    int aceitas = 0;
    std::vector<std::string> rejeitadas;
};

// Fachada da regra de negócio. A interface Qt conversa apenas com esta classe,
// evitando SQL, CSV e validações espalhados pelos botões da tela.
class GerenciadorCanais {
public:
    GerenciadorCanais();

    const std::vector<Imovel>& imoveis() const { return imoveis_; }
    const std::vector<Hospede>& hospedes() const { return hospedes_; }
    Imovel* buscarImovel(int id);
    const Imovel* buscarImovel(int id) const;
    Hospede* buscarHospede(const std::string& documento);
    const Hospede* buscarHospede(const std::string& documento) const;

    int criarImovel(const std::string& nome, const std::string& endereco, double diaria, int capacidade,
                    const std::string& descricao, const std::string& foto);
    void atualizarImovel(int id, const std::string& nome, const std::string& endereco, double diaria, int capacidade,
                         const std::string& descricao, const std::string& foto);
    void excluirImovel(int id);

    void salvarHospede(const Hospede& hospede); // cadastra ou atualiza pelo documento
    void excluirHospede(const std::string& documento);

    int registrarReserva(int idImovel, const std::string& documentoHospede, Data entrada, Data saida,
                         int quantidadeHospedes, const std::string& canal, const std::string& pagamento,
                         const std::string& observacoes);
    void mudarStatusReserva(int idImovel, int idReserva, StatusReserva status);
    void excluirReserva(int idImovel, int idReserva);
    double preverTotal(int idImovel, Data entrada, Data saida) const;
    double valorLiquido(const Reserva& reserva) const;
    ResumoFinanceiro resumo(int mes, int ano) const;

    void salvar(const std::string& diretorio) const;
    void carregar(const std::string& diretorio);
    void exportarReservasCsv(const std::string& arquivo) const;
    ResultadoImportacao importarAirbnb(const std::string& arquivo);

private:
    const Plataforma* plataforma(const std::string& nome) const;
    static std::vector<std::string> separar(const std::string& linha);
    static std::string limparCampo(std::string texto);
    std::vector<Imovel> imoveis_;
    std::vector<Hospede> hospedes_;
    std::vector<std::unique_ptr<Plataforma>> plataformas_;
    int proximoIdImovel_ = 1;
    int proximoIdReserva_ = 1;
};
