cmake_minimum_required(VERSION 3.21)
project(GestorAlugueisQt VERSION 1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

find_package(Qt6 REQUIRED COMPONENTS Widgets)

set(DOMINIO
    src/domain/gerenciador.cpp
)

add_executable(GestorAlugueis
    src/main.cpp
    src/gui/logindialog.cpp
    src/gui/mainwindow.cpp
    ${DOMINIO}
)
target_include_directories(GestorAlugueis PRIVATE src)
target_link_libraries(GestorAlugueis PRIVATE Qt6::Widgets)

# Teste sem Qt: confirma as regras mais importantes também em ambiente de console.
include(CTest)
if(BUILD_TESTING)
    add_executable(test_domain tests/test_domain.cpp ${DOMINIO})
    target_include_directories(test_domain PRIVATE src)
    add_test(NAME regras_de_negocio COMMAND test_domain)
endif()
