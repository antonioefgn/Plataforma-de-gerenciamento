#include "paginaimoveis.h"
#include "ui_paginaimoveis.h"

#include <QHeaderView>

PaginaImoveis::PaginaImoveis(QWidget *parent) : QWidget(parent), ui(new Ui::PaginaImoveis)
{
    ui->setupUi(this);
    ui->tabelaImoveis->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->splitter->setStretchFactor(0, 2);
    ui->splitter->setStretchFactor(1, 3);
}

PaginaImoveis::~PaginaImoveis()
{
    delete ui;
}

void PaginaImoveis::resizeEvent(QResizeEvent *e)
{
    QWidget::resizeEvent(e);
    ui->splitter->setOrientation(width() < 860 ? Qt::Vertical : Qt::Horizontal);
}
