#pragma once

#include <QWidget>

namespace Ui { class PaginaImoveis; }

// Tela apenas visual (nenhum botão faz nada ainda). O layout está em paginaimoveis.ui.
// Quando a janela fica estreita, lista e formulário passam a ficar um sobre o outro.
class PaginaImoveis : public QWidget {
public:
    explicit PaginaImoveis(QWidget *parent = nullptr);
    ~PaginaImoveis() override;

protected:
    void resizeEvent(QResizeEvent *e) override;

private:
    Ui::PaginaImoveis *ui;
};
