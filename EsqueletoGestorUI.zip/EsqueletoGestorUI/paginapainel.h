#pragma once

#include <QWidget>

namespace Ui { class PaginaPainel; }

// Tela apenas visual. O layout está em paginapainel.ui.
class PaginaPainel : public QWidget {
public:
    explicit PaginaPainel(QWidget *parent = nullptr);
    ~PaginaPainel() override;

private:
    Ui::PaginaPainel *ui;
};
