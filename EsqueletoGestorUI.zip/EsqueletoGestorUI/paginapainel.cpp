#include "paginapainel.h"
#include "ui_paginapainel.h"

PaginaPainel::PaginaPainel(QWidget *parent) : QWidget(parent), ui(new Ui::PaginaPainel)
{
    ui->setupUi(this);
}

PaginaPainel::~PaginaPainel()
{
    delete ui;
}
