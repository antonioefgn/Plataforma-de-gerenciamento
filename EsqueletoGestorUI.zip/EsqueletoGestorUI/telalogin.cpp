#include "telalogin.h"
#include "ui_telalogin.h"

// Credenciais padrão
static const QString Usuario = "admin";
static const QString Senha = "1234";

TelaLogin::TelaLogin(QWidget *parent) : QDialog(parent), ui(new Ui::TelaLogin)
{
    ui->setupUi(this);

    connect(ui->chkMostrarSenha, &QCheckBox::toggled, this, [this](bool on) {
        ui->editSenha->setEchoMode(on ? QLineEdit::Normal : QLineEdit::Password);
    });
    connect(ui->btnEntrar, &QPushButton::clicked, this, [this] { tentarLogin(); });
    connect(ui->editUsuario, &QLineEdit::returnPressed, this, [this] { ui->editSenha->setFocus(); });
    connect(ui->editSenha, &QLineEdit::returnPressed, this, [this] { tentarLogin(); });
    ui->editUsuario->setFocus();
}

TelaLogin::~TelaLogin()
{
    delete ui;
}

void TelaLogin::tentarLogin()
{
    if (ui->editUsuario->text().trimmed() == Usuario && ui->editSenha->text() == Senha) {
        accept();
        return;
    }
    ui->erro->setText(tr("Usuário ou senha incorretos."));
    ui->editSenha->clear();
    ui->editSenha->setFocus();
}
