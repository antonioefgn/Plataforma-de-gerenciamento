#include "paginareservas.h"
#include "ui_paginareservas.h"

#include <QDate>
#include <QHeaderView>

PaginaReservas::PaginaReservas(QWidget *parent) : QWidget(parent), ui(new Ui::PaginaReservas)
{
    ui->setupUi(this);

    ui->tabelaReservas->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->splitter->setStretchFactor(0, 2);
    ui->splitter->setStretchFactor(1, 3);
    ui->dateCheckIn->setDate(QDate::currentDate());
    ui->dateCheckOut->setDate(QDate::currentDate().addDays(1));

    // Único comportamento além do login: alternar visualmente entre os dois modos
    connect(ui->radioVer, &QRadioButton::toggled, this,
            [this](bool ver) { ui->painel->setCurrentIndex(ver ? 0 : 1); });
}

PaginaReservas::~PaginaReservas()
{
    delete ui;
}

void PaginaReservas::resizeEvent(QResizeEvent *e)
{
    QWidget::resizeEvent(e);
    ui->splitter->setOrientation(width() < 900 ? Qt::Vertical : Qt::Horizontal);
}
