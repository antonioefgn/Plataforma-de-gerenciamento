#pragma once

#include <QWidget>

namespace Ui { class PaginaClientes; }

// Tela apenas visual (nenhum botão faz nada ainda). O layout está em paginaclientes.ui.
// Quando a janela fica estreita, lista e formulário passam a ficar um sobre o outro.
class PaginaClientes : public QWidget {
public:
    explicit PaginaClientes(QWidget *parent = nullptr);
    ~PaginaClientes() override;

protected:
    void resizeEvent(QResizeEvent *e) override;

private:
    Ui::PaginaClientes *ui;
};
