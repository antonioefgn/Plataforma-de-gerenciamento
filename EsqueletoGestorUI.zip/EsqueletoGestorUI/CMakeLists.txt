cmake_minimum_required(VERSION 3.16)
project(EsqueletoGestor VERSION 1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTOUIC ON)   # gera ui_*.h a partir dos arquivos .ui
set(CMAKE_INCLUDE_CURRENT_DIR ON)  # permite que os .ui encontrem os headers das telas

find_package(Qt6 REQUIRED COMPONENTS Widgets)

add_executable(EsqueletoGestor WIN32 MACOSX_BUNDLE
    main.cpp
    telalogin.h          telalogin.cpp          telalogin.ui
    mainwindow.h         mainwindow.cpp         mainwindow.ui
    paginapainel.h       paginapainel.cpp       paginapainel.ui
    paginaimoveis.h      paginaimoveis.cpp      paginaimoveis.ui
    paginareservas.h     paginareservas.cpp     paginareservas.ui
    paginaclientes.h     paginaclientes.cpp     paginaclientes.ui
)

target_link_libraries(EsqueletoGestor PRIVATE Qt6::Widgets)
