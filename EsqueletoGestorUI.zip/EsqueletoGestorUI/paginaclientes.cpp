#include "paginaclientes.h"
#include "ui_paginaclientes.h"

#include <QHeaderView>

PaginaClientes::PaginaClientes(QWidget *parent) : QWidget(parent), ui(new Ui::PaginaClientes)
{
    ui->setupUi(this);
    ui->tabelaClientes->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->splitter->setStretchFactor(0, 3);
    ui->splitter->setStretchFactor(1, 2);
}

PaginaClientes::~PaginaClientes()
{
    delete ui;
}

void PaginaClientes::resizeEvent(QResizeEvent *e)
{
    QWidget::resizeEvent(e);
    ui->splitter->setOrientation(width() < 860 ? Qt::Vertical : Qt::Horizontal);
}
