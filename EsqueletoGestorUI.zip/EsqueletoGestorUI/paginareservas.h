#pragma once

#include <QWidget>

namespace Ui { class PaginaReservas; }

// Tela apenas visual (nenhum botão faz nada ainda). O layout está em paginareservas.ui.
// Quando a janela fica estreita, lista e formulário passam a ficar um sobre o outro.
class PaginaReservas : public QWidget {
public:
    explicit PaginaReservas(QWidget *parent = nullptr);
    ~PaginaReservas() override;

protected:
    void resizeEvent(QResizeEvent *e) override;

private:
    Ui::PaginaReservas *ui;
};
